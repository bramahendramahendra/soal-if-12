        <main>
            <section id="search" class="page-id">
                <div class="header-search bgcover">
                    <div class="container">
                        <div id="searchbox">
                            <h2>Temukan acara dan kegiatan seru di kiosTix!</h2>
                            <div>
                                <form method="GET" action="search" accept-charset="UTF-8" class="searchform typeahead"
                                    role="search">
                                    <input type="text" name="q" value="" style="color: grey;"
                                        class="input-search search-input" placeholder="Cari event kamu di sini"
                                        autocomplete="off">
                                    <button type="submit" class="btn-search" name="submit"><i
                                            class="icon ion-ios-search"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <div class="section">
                <section id="section-explore" class="sections">
                    <div class="container">
                        <div class="titleBox no-border center">
                            <h2 class="title">Explore</h2>
                        </div>

                        <div id="explore-content">
                            <div class="ex-boxWrap max800 flex-center">
                                <div class="ex-boxing">
                                    <a href="<?php echo base_url('eve/eventt') ?>" class="flex  ">
                                        <div class="ex-img"><img src="assets/img/ex-1.jpg"></div>
                                        <div class="ex-title">
                                            <h2>Events</h2>
                                        </div>
                                    </a>
                                </div>
                                <div class="ex-boxing">
                                    <a href="#" class="flex  ">
                                        <div class="ex-img"><img src="assets/img/ex-2.jpg"></div>
                                        <div class="ex-title">
                                            <h2>Aktivitas dan Hiburan</h2>
                                        </div>
                                    </a>
                                </div>

                            </div>
                        </div>

                    </div>
                </section>
                <section id="section-featured" class="sections desktop">
                    <div class="container">
                        <div class="titleBox no-border center">
                            <h2 class="title">Rekomendasi</h2>
                        </div>
                        <div id="myCarousel" class="carousel slide" data-ride="carousel">
                            <!-- Indicators -->
                            <ol class="carousel-indicators">
                                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                                <li data-target="#myCarousel" data-slide-to="1"></li>
                            </ol>

                            <!-- Wrapper for slides -->
                            <div class="carousel-inner">
                                <div class="item active">
                                    <div class="row">
                                        <?php foreach ($data as $d) {?>

                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="<?= base_url(); ?>eve/detailevent/<?= $d->id ?>">
                                                            <img src="<?php echo base_url('images/').$d->foto ?>">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3><?php echo $d->judul ?></h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <?php } ?>

                                    </div>
                                </div>







                                <div class="item">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="#">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="#">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="#">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="#">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="#">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="#">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="#">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="#">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Left and right controls -->
                            <a class="owl-prev" href="#myCarousel" data-slide="prev">
                                <i class="icon ion-ios-arrow-back" style="font-size:36px; color: grey;"></i>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="owl-next" href="#myCarousel" data-slide="next">
                                <i class="icon ion-ios-arrow-forward" style="font-size:36px; color: grey;"></i>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </section>
                <section id="section-newest" class="sections">
                    <div class="container">
                        <div class="titleBox no-border center">
                            <h2 class="title">Event</h2>
                            <a href="events" class="btn-line seeAll">Lihat Semua <i class="ion-chevron-right"></i></a>
                        </div>
                        <div id="myCarousel2" class="carousel slide" data-ride="carousel">
                            <!-- Indicators -->
                            <ol class="carousel-indicators">
                                <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
                                <li data-target="#myCarousel" data-slide-to="1"></li>
                            </ol>

                            <!-- Wrapper for slides -->
                            <div class="carousel-inner">
                                <div class="item active">
                                    <div class="row">


                                      <?php foreach ($data as $d) {?>

                                      <div class="col-md-3">
                                          <div class="items">
                                              <div class="event-box box">
                                                  <div class="event-image thumb">
                                                      <a href="<?= base_url(); ?>eve/detailevent/<?= $d->id ?>">
                                                          <img src="<?php echo base_url('images/').$d->foto ?>">
                                                      </a>
                                                  </div>
                                                  <div class="event-entry">
                                                      <h3><?php echo $d->judul ?></h3>
                                                  </div>
                                              </div>
                                          </div>
                                      </div>

                                      <?php } ?>


                                    </div>
                                </div>


                            </div>

                            <!-- Left and right controls -->
                            <a class="owl-prev" href="#myCarousel2" data-slide="prev">
                                <i class="icon ion-ios-arrow-back" style="font-size:36px; color: grey;"></i>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="owl-next" href="#myCarousel2" data-slide="next">
                                <i class="icon ion-ios-arrow-forward" style="font-size:36px; color: grey;"></i>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </section>
                <section id="section-family" class="sections">
                    <div class="container">
                        <div class="titleBox no-border center">
                            <h2 class="title">Aktivitas & Hiburan</h2>
                            <a href="#" class="btn-line seeAll">Lihat Semua <i class="ion-chevron-right"></i></a>
                        </div>
                        <div id="myCarousel3" class="carousel slide" data-ride="carousel">
                            <!-- Indicators -->
                            <ol class="carousel-indicators">
                                <li data-target="#myCarouse2" data-slide-to="0" class="active"></li>
                                <li data-target="#myCarouse2" data-slide-to="1"></li>
                            </ol>

                            <!-- Wrapper for slides -->
                            <div class="carousel-inner">
                                <div class="item active">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="#">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="#">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="#">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="item">
                                    <div class="row">
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="#">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="#">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="#">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3">
                                            <div class="items">
                                                <div class="event-box box">
                                                    <div class="event-image thumb">
                                                        <a href="#">
                                                            <img src="assets/img/small.jpg">
                                                        </a>
                                                    </div>
                                                    <div class="event-entry">
                                                        <h3>Meranoia Festival</h3>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Left and right controls -->
                            <a class="owl-prev" href="#myCarousel3" data-slide="prev">
                                <i class="icon ion-ios-arrow-back" style="font-size:36px; color: grey;"></i>
                                <span class="sr-only">Previous</span>
                            </a>
                            <a class="owl-next" href="#myCarousel3" data-slide="next">
                                <i class="icon ion-ios-arrow-forward" style="font-size:36px; color: grey;"></i>
                                <span class="sr-only">Next</span>
                            </a>
                        </div>
                    </div>
                </section>
            </div>
        </main>
