    <main>
      <section id="section-details" class="section">
    <div class="container">
      <div class="thanksPage">
      <div class="row">
        <div class="col-md-12">
          <div class="event-meta center">
                          <h1>Terima Kasih</h1>
                      </div>
        </div>
        <div class="col-md-12"> 
            <div class="order-detail widget-options center">
                              <div class="widget-head">
  <h3>Pesanan Tiket <br><span class="orange"><?php echo $event['judul'] ?><br></span> Kamu Telah Berhasil Diproses </h3>
</div>
<div class="event-image thumb">
  <img src="<?php echo base_url() ?>images/<?php echo $event['foto']?>">
</div>
  <div class="widget-body">
    <div class="row">
      <div class="col-md-6">
        <div class="greybox">
          <span>Total Pembayaran: </span>
           <h3 style="margin:0;"><strong>Rp.<?php echo number_format($event['harga'] , 0, ',', '.');?></strong></h3>
        </div>
      </div>
      <div class="col-md-6">
        <div class="greybox">
          <span>Metode Pembayaran: </span>
           <h3 style="margin:0;"><strong><?php echo $bayar['metode_bayar'] ?></strong></h3>
        </div>
      </div>
    </div>
        <div class="row">
          <div class="col-md-12">
            <div class="greybox">
              <span>Order ID: </span>
               <h3 style="margin:0;"><strong><?php echo $bayar['id'] ?></strong></h3>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12">
            <div class="greybox">
              
                            <span>Untuk menyelesaikan pembayaran dengan GO-PAY, buka aplikasi GO-JEK dan scan kode QR </span>
              <br>
              <img height="200" width="200" src="<?php echo $bayar['barcode'] ?>" alt="">
                            <br>
              <div class="center">
                <br>
                <span>Sisa Waktu Pembayaran </span>
                <h3 style="margin:0;"><div id="countdownExpGopay" event-id="522" transaction-id="504861"><span id="countdown" class="timer"></span></div></h3>
                <script>
                          var initialTime = 900;//Place here the total of seconds you receive on your PHP code. ie: var initialTime = <? echo $remaining; ?>;
                          var seconds = initialTime;
                          function timer() {
                              var days        = Math.floor(seconds/24/60/60);
                              var hoursLeft   = Math.floor((seconds) - (days*86400));
                              var hours       = Math.floor(hoursLeft/3600);
                              var minutesLeft = Math.floor((hoursLeft) - (hours*3600));
                              var minutes     = Math.floor(minutesLeft/60);
                              var remainingSeconds = seconds % 60;
                              if (remainingSeconds < 10) {
                                  remainingSeconds = "0" + remainingSeconds; 
                              }
                              document.getElementById('countdown').innerHTML = hours + " : " + minutes + " : " + remainingSeconds;
                              if (seconds == 0) {
                                  clearInterval(countdownTimer);
                                  document.getElementById('countdown').innerHTML = "Completed";
                              } else {
                                  seconds--;
                              }
                          }
                          var countdownTimer = setInterval('timer()', 1000);
                        </script>
                <h4 style="margin:0;"><strong><?php echo date("d/m/Y",strtotime($bayar['timestamp']))?><br><?php echo date('h:i:s',strtotime($bayar['timestamp'])) ?></strong></h4>
              </div>
            </div>
          </div>
        </div>
      <br>
                <h3>e-voucher akan dikirim ke email setelah pembayaran selesai<br><?php echo $user['email'] ?></h3>
              <br>
              <div class="share-box">
          <h4>Bagikan event ini dan ajak temanmu</h4>
           <div class="sharebox flex-center">
        <ul>
          <li>
          <a href="#" class="shareFacebook" data-name="Musik Tanggal Merah Tulus" data-link="https://www.kiostix.com/event/musik-tanggal-merah-tulus" data-picture="https://www.kiostix.com/media/" data-caption="" data-post="522" data-user=""><i class="icon-brand-facebook"></i></a>
          </li>
          <li>
          <a href="#" class="shareTwitter" data-text="Musik Tanggal Merah Tulus" data-shareurl="https://www.kiostix.com/event/522/musik-tanggal-merah-tulus" data-via="kiostix" data-hastag="kiostix" data-user=""><i class="icon-brand-twitter"></i></a>
          </li>
          <li>
            <a class="shareWhatsapp" href="https://api.whatsapp.com/send?text=https://www.kiostix.com/event/522/musik-tanggal-merah-tulus" target="_blank">
              <i class="icon-brand-whatsapp"></i>
            </a>
          </li>
          <li>
            <a class="shareLine" href="line://msg/text/https://www.kiostix.com/event/522/musik-tanggal-merah-tulus" target="_blank">
              <i class="icon-brand-line"></i>
            </a>
          </li>
        </ul>
        </div>        </div>
        </div>
  <div class="howTo-pay">
    <p>1. Click “Bayar menggunakan GOPAY”<br>2. Open your GO-JEK Application in your device<br>3. Click Pay<br>4. Point your device camera to the QR Code on the screen<br>5. Check your payment details in your GO-JEK Application and press Pay<br>6. Your transaction is completed</p>
  </div>
  <script>
    var expTime = '2019-04-19 22:52:29';
    $("#countdownExpGopay").countdown(expTime, function(event) {
      $(this).html(
        event.strftime('<strong>%M</strong> <span>Menit</span> <strong>%S</strong> <span>Detik</span>')
      )}).on('finish.countdown', function() {
          var eventID = $(this).attr('event-id');
          var trxId = $(this).attr('transaction-id')
            var data = {
                _token: token,
                trxId: trxId,
                eventID: eventID,
          }
          $.ajax({
            method: "POST",
            url: base_url+"/expired",
            data : data
          }).done(function(data) {
              $("#popup-title").text("Maaf,");
              $("#popup-text").html("Pesanan anda sudah melewati batas waktu pembayaran.");
              common.popup()
               setTimeout(function () {
                     var url = base_url+data.url;
                     window.location = url;
                }, 4000);
          }).fail(function (jqXHR, textStatus, errorThrown) {
                $("#popup-title").text("Ooops!");
                $("#popup-text").text("Please try again.");
                common.popup()
            });
          return false;
      });
  </script>                             </div>
        </div>
      </div>
      </div>
    </div>
    <div class="thxleft"></div>
    <div class="thxright"></div>
  </section>
  <script>
    var expTime = '2019-04-19 22:52:29';
    $("#countdownExpPay").countdown(expTime, function(event) {
      $(this).html(
        event.strftime('<strong>%H</strong> <span>Jam</span>  <strong>%M</strong> <span>Menit</span> <strong>%S</strong> <span>Detik</span>')
      )}).on('finish.countdown', function() {
          var eventID = $(this).attr('event-id');
          var trxId = $(this).attr('transaction-id')
            var data = {
                _token: token,
                trxId: trxId,
                eventID: eventID,
          }
          $.ajax({
            method: "POST",
            url: base_url+"/expired",
            data : data
          }).done(function(data) {
              $("#popup-title").text("Maaf,");
              $("#popup-text").html("Pesanan anda sudah melewati batas waktu pembayaran.");
              common.popup()
               setTimeout(function () {
                     var url = base_url+data.url;
                     window.location = url;
                }, 4000);
          }).fail(function (jqXHR, textStatus, errorThrown) {
                $("#popup-title").text("Ooops!");
                $("#popup-text").text("Please try again.");
                common.popup()
            });
          return false;
      });
  </script>
    </main>