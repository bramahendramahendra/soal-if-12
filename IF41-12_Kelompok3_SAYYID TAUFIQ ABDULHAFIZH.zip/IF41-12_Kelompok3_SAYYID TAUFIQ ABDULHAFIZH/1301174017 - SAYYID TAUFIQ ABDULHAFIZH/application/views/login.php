<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
</head>
<body>
    <div class="mfp-bg my-mfp-zoom-in mfp-ready"></div>
    <div class="mfp-wrap mfp-close-btn-in mfp-auto-cursor my-mfp-zoom-in mfp-ready" tabindex="-1" style="top: 0px; position: absolute; height: 618px;">
        <div class="mfp-container mfp-inline-holder">
            <div class="mfp-content">
                <div class="popup-container" id="popup-login">
                    <div class="popup-header">
                        <h3>Login</h3>
                    </div>
                    <div class="popup-body">
                        <form class="login-form" role="form" method="POST" action="Log/masuk">
                            <input type="hidden" name="_token" value="4d7avNBXjtpAbX9RFsNBDGRS0OUlTuzb6h8wd6u7">
                            <div class="form-group">
                                <input id="email" type="email" class="form-control" placeholder="Email" name="email" value="" required="" autofocus="">
                            </div>
                            <div class="form-group">
                                <input id="password" type="password" class="form-control" placeholder="Kata Sandi" name="pass" autocomplete="off" required="">
                            </div>
                            <div class="form-group">
                                <div class="remember-me">
                                    <input type="checkbox" name="remember" class="checkbox">
                                    <label>Ingatkan saya</label>
                                </div>
                            </div>
                            <div class="form-group center">
                                <div class="row">
                                    <div class="col-md-6">
                                        <button type="submit" class="button setCookie">Masuk</button>
                                    </div>
                                    <div class="col-md-6">
                                        <a class="button showPopup" href="https://kiostix.com/id#popup-register">Daftar</a>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group center">
                                <span>atau</span>
                            </div>
                            <div class="form-group center">
                                <div class="socialLogin">
                                    <a href="https://kiostix.com/redirect/facebook" class="button loginFacebook setCookie" data-url="https://kiostix.com/id"><i class="ion-social-facebook"></i>Login</a>
                                    <a href="https://kiostix.com/redirect/google" class="button loginGoogle setCookie" data-url="https://kiostix.com/id"> <i class="ion-social-googleplus"></i>Login</a>
                                </div>
                            </div>
                            <div class="form-group center">
                                <a class="btn btn-link" href="https://kiostix.com/password/reset">Lupa Kata Sandi</a>
                            </div>
                        </form>        
                    </div>
                    <button title="Close (Esc)" type="button" class="mfp-close">×</button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>