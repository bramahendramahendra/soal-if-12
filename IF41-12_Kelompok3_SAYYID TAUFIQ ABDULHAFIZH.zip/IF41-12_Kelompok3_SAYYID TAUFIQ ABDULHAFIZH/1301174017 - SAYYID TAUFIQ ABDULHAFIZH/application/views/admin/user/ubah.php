<div class="container">
    <div class="titleBox flex flex-center">
        <h2 class="title text-center" id="titleFilters">Edit User</h2>
    </div>
    <div class="theContents Events">
        <div class="scroll">
            <div id="data" class="event-list">
                <!-- isi form ini -->
                <form method="POST" action="">
                    <input type="hidden" name="id" value="<?= $user['id'] ?>">
                    <div class="form-group">
                        <input id="fullname" type="text" class="form-control" name="nama"
                            placeholder="Nama Panjang (sesuai KTP/Passport/SIM)" value="<?= $user['nama']; ?>" required
                            autofocus>
                    </div>
                    <div class="form-group">
                        <div class="row">
                            <div class="col-md-3">
                                <div class="phoneCodeBox">
                                    <select name="hp_code" id="phone_code" class="form-control select"
                                        data-live-search="true">
                                        <option value="93">+93 - Afghanistan</option>
                                        <option value="93">+93 - asda</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-9">
                                <input class="form-control" placeholder="No. Handphone" name="hp" type="text"
                                    value="<?= $user['hp']; ?>">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <input class="form-control dob" placeholder="Tanggal Lahir (dd/mm/yyyy)" name="bday" type="text"
                            value="<?= $user['bday']; ?>">
                    </div>
                    <div class="form-group">
                        <select name="negara" id="country_id" class="form-control select">
                            <option value="1">Afghanistan</option>
                            <option value="1">Afghanistan</option>
                        </select>
                    </div>

                    <div class="form-group">

                        <input type="email" class="form-control" name="email" placeholder="Email"
                            value="<?= $user['email']; ?>" required>

                    </div>
                    <div class="modal-footer">
                        <a href="<?php echo base_url() ?>user"><button type="button" class="btn btn-secondary" data-dismiss="modal">Kembali</button></a>
                        <input type="submit" class="btn btn-primary" id="hapus" value="Submit" placeholder="Simpan">
                    </div>
                </form>
            </div>

        </div>
    </div>
</div>