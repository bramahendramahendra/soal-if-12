<main>
    <section id="section-details" class="section payment-detail">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="payMentBox">
                        <div class="order-detail widget-options">
                            <div class="widget-head">
                                <h3>Rincian Pemesanan</h3>
                            </div>
                            <div class="widget-body">
                                <div class="asdr">
                                    <p>
                                        <strong class="full_name"><?php echo $user['nama']?></strong><br>
                                        <span class="full_name"><?php echo $user['email']?></span><br>
                                        <span class="full_name"></span><br>
                                    </p>
                                    <p><br>
                                        <strong id="event-title" data-id="522"><?php echo $event['judul']?></strong><br>
                                        <span class="date start-date">
                                        <?php echo date("l", strtotime($event['tanggal'])) ?>,
                                    <?php echo date("d F Y",strtotime($event['tanggal']))?>
                                        </span>
                                        |
                                    <?php echo $event['waktu']?>
                                        <br>
                                        <span class="venue_name"><?php echo $event['tempat']?></span>
                                        <br><br>
                                    </p><br>
                                </div>
                                <br>
                                <div id="booking-detail" class="booking-details">
                                    <div class="booking-header flex-center">
                                        <div class="colom-info col3">
                                            <span>Harga/Section</span>
                                        </div>
                                        <div class="colom-left col3 center">
                                            <span>Kuantitas</span>
                                        </div>
                                        <div class="colom-right col3 text-right">
                                            <span>Subtotal</span>
                                        </div>
                                    </div>
                                    <div class="booking-body">
                                        <div class="row-section-ticket">
                                            <div class="section-name">
                                                <span class="labels ticket-name">
                                                    <?php echo $event['jenis_tiket']?>
                                                </span><br>
                                            </div>
                                            <div class="flex-center">
                                                <div class="colom-info col3">
                                                    <span class="product-price">Rp.<?php //perbaiki baris ini?></span>
                                                </div>
                                                <div class="colom-info col3 center">
                                                    <span class="product-qty">x <?php echo $quantity?></span>
                                                </div>
                                                <div class="colom-info col3 text-right">
                                                    <span class="product-price">Rp.<?php echo number_format($event['harga']*$quantity , 0, ',', '.');?></span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="booking-detail">
                                        <div class="booking-footer">
                                            <div class="item-row booking-section">
                                                <span class="product-item">Jumlah</span>
                                                <span class="product-price total-price">Rp.
                                                    <strong><?php echo number_format($event['harga']*$quantity , 0, ',', '.');?></strong></span>
                                            </div>
                                            <div class="item-row f14 booking-section">
                                                <span class="product-item">Fee</span>
                                                <span class="product-price">Rp. <span id="feePayment">0</span></span>
                                            </div>
                                            <div id="voucherBox">
                                                <div class="item-row f14 booking-section" id="voucherGroup">
                                                    <span class="product-item">Kode Voucher (Jika Ada)</span>
                                                    <div class="inputgroup">
                                                        <div class="loading loading-double hide" id="loader-voucher">
                                                        </div>
                                                        <input type="text" name="voucher" id="voucher">
                                                        <a href="#"
                                                            class="button btn-outline btn-s submitVoucher btn-grey"
                                                            data-event="522">Submit</a>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="item-row booking-section" id="totalPriceBox">
                                                <span class="product-item">Total</span>
                                                <span class="product-price total-price" id="totalPrice"
                                                    data-value="357000.00">Rp. <span
                                                        id="totalPriceValue"><?php echo number_format($event['harga']*$quantity , 0, ',', '.');?></span></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <script>
                          var initialTime = 600;//Place here the total of seconds you receive on your PHP code. ie: var initialTime = <? echo $remaining; ?>;
                          var seconds = initialTime;
                          function timer() {
                              var days        = Math.floor(seconds/24/60/60);
                              var hoursLeft   = Math.floor((seconds) - (days*86400));
                              var hours       = Math.floor(hoursLeft/3600);
                              var minutesLeft = Math.floor((hoursLeft) - (hours*3600));
                              var minutes     = Math.floor(minutesLeft/60);
                              var remainingSeconds = seconds % 60;
                              if (remainingSeconds < 10) {
                                  remainingSeconds = "0" + remainingSeconds;
                              }
                              document.getElementById('countdown').innerHTML = hours + " : " + minutes + " : " + remainingSeconds;
                              if (seconds == 0) {
                                  clearInterval(countdownTimer);
                                  document.getElementById('countdown').innerHTML = "Completed";
                              } else {
                                  seconds--;
                              }
                          }
                          var countdownTimer = setInterval('timer()', 1000);
                        </script>
                        <div id="countdown-block">
                            <h3>Sisa Waktu</h3>
                              <span id="countdown" class="timer"></span>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="payMentBox">
                        <div class="order-detail widget-options payment-method">
                            <div class="widget-head">
                                <h3>Metode Pembayaran</h3>
                            </div>
                            <div class="panel-group accordion-border" id="accordion-payment" role="tablist"
                                aria-multiselectable="true">
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="payment-86" data-typepyment="credit_card"
                                        data-accuring="cimb">
                                        <h4 class="panel-title">
                                            <a role="button" data-toggle="collapse"
                                                class="flex-center collapsed sectionBtn section-disable"
                                                data-parent="#accordion-payment" title="Credit Card"
                                                href="#payment-section-86" aria-expanded="true"
                                                aria-controls="ticket-section-86" title="Credit Card">
                                                Credit Card
                                                <img src="https://www.kiostix.com/images/credit_card.png"
                                                    style="width: 79px; height: 20px;" alt="">
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="payment-section-86" class="panel-collapse collapse" role="tabpanel"
                                        aria-labelledby="86" title="Credit Card" data-typepyment="credit_card"
                                        data-accuring="cimb">
                                        <div class="panel-body">
                                            <form action="#" method="POST"
                                                id="payment-form-86">
                                                <input type="hidden" name="_token"
                                                    value="bGF86yP5lGvbOv0rfK1WUi7ym27YIBpyrqZ6IWW2">

                                                <input type="hidden"
                                                    value="eyJpdiI6InZzXC90bUpNNVB5d3RWbnA5STYyV2VnPT0iLCJ2YWx1ZSI6IkFKMmNOWUc5a3hvXC93OTNzRzkwZklMSDgxQjJvXC8wT3BwTzl1Q1UrME5KTT0iLCJtYWMiOiJhYmNlODI2MWU1NzAxYmU1OGM4ZTU3MjU5MDFhZmI1YWQzY2ZiZjM4NGUzZmJiZGU2MmVkNjAyYmNjMmNjNzNiIn0="
                                                    name="key">
                                                <input type="hidden" value="86" name="payment_method_id">
                                                <input type="hidden" value="credit_card" name="payment_type">
                                                <input type="hidden" class="voucher_code" name="voucher_code">
                                                <input type="hidden" class="voucher_id" name="voucher_id">
                                                <input type="hidden" class="voucher_value" name="voucher_value">
                                                <input type="hidden" value="cimb" name="accuiring">
                                                <div class="booking-section row">
                                                    <div class="col-md-12">
                                                        <label for="">Nomor Kartu</label>
                                                        <input class="card-number form-control card-no cardNo-86"
                                                            value="" size="20" type="text" autocomplete="off" />
                                                    </div>
                                                </div>
                                                <div class="booking-section row">
                                                    <div class="col-md-12">
                                                        <label for="">Nama Pemegang Kartu</label>
                                                        <input class="card-number card-name form-control" value=""
                                                            size="20" type="text" autocomplete="off" />
                                                    </div>
                                                </div>
                                                <div class="booking-section booking-cc">
                                                    <div class="row">
                                                        <div class="col-md-8">
                                                            <label for="">Tanggal Masa Berlaku</label>
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <input class="card-expiry-month" value=""
                                                                        placeholder="MM" size="2" type="text" />
                                                                </div>
                                                                <div class="col-md-6">
                                                                    <input class="card-expiry-year" value=""
                                                                        placeholder="YYYY" size="4" type="text" />
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="col-md-4">
                                                            <label for="">CV/CVV</label>
                                                            <input class="card-cvv" value="" size="4" type="password"
                                                                autocomplete="off" />
                                                        </div>
                                                    </div>
                                                </div>
                                                <input id="token_id" name="token_id" type="hidden" />
                                                <input type="hidden" name="gross_amount" value="" id="gross_amount">
                                            </form>

                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="payment-87"
                                        data-typepyment="bank_transfer" data-accuring="permata">
                                        <h4 class="panel-title">
                                            <a role="button" data-toggle="collapse"
                                                class="flex-center collapsed sectionBtn section-disable"
                                                data-parent="#accordion-payment" title="Bank Transfer"
                                                href="#payment-section-87" aria-expanded="true"
                                                aria-controls="ticket-section-87" title="Bank Transfer">
                                                Bank Transfer
                                                <img src="https://www.kiostix.com/images/bank_transfer.png"
                                                    style="width: 79px; height: 20px;" alt="">
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="payment-section-87" class="panel-collapse collapse" role="tabpanel"
                                        aria-labelledby="87" title="Bank Transfer" data-typepyment="bank_transfer"
                                        data-accuring="permata">
                                        <div class="panel-body">
                                            <h3>Petunjuk Umum Pembayaran:</h3>
                                            <p><strong>Pembayaran menggunakan ATM BCA (jaringan ATM PRIMA)</strong></p>
                                            <ol>
                                                <li>Pilih "Transaksi lainnya" &amp; "transfer kepada bank lain"</li>
                                                <li>Pilih bank Permata (kode bank 013)</li>
                                                <li>Masukan jumlah pembayaran yang sesuai dengan tagihan yang diberikan
                                                    (kesalahan input atas jumlah pembayaran dapat menyebabkan pesanan
                                                    anda dibatalkan secara otomatis)</li>
                                                <li>Masukan nomor Virtual Account <strong> XXXXXX XXXXXX XXXX</strong>
                                                </li>
                                                <li>Pastikan jumlah pembayaran, bank (kode bank), nomor akun virtual,
                                                    telah benar sebelum melakukan konfirmasi atas pembayaran yang akan
                                                    anda lakukan</li>
                                                <li>Mohon simpan baik-baik bukti pembayaran anda</li>
                                                <li>Setelah transaksi anda dapat di verifikasi/ tervalidasi; sistem akan
                                                    mengirimkan E-voucher/ E-ticket anda dan selamat menikmati
                                                    pertunjukan yang ada</li>
                                            </ol>
                                            <p><strong>Pembayaran menggunakan ATM MANDIRI (jaringan ATM
                                                    BERSAMA)</strong></p>
                                            <ol>
                                                <li>Pilih "Transaksi lainnya"</li>
                                                <li>Pilih "Transfer antar bank online"</li>
                                                <li>Masukan kode bank dan nomor Virtual Account <strong>013 XXXXXX
                                                        XXXXXX XXXX</strong></li>
                                                <li>Masukan jumlah pembayaran yang sesuai dengan tagihan yang diberikan
                                                    (kesalahan input atas jumlah pembayaran dapat menyebabkan pesanan
                                                    anda dibatalkan secara otomatis)</li>
                                                <li>Pastikan jumlah pembayaran, bank (kode bank), nomor akun virtual,
                                                    telah benar sebelum melakukan konfirmasi atas pembayaran yang akan
                                                    anda lakukan</li>
                                                <li>Mohon simpan baik-baik bukti pembayaran anda</li>
                                                <li>Setelah transaksi anda dapat di verifikasi/ tervalidasi; sistem akan
                                                    mengirimkan E-voucher/ E-ticket anda dan selamat menikmati
                                                    pertunjukan yang ada</li>
                                            </ol>
                                            <p><strong>Pembayaran menggunakan ATM Bank Permata (jaringan ATM
                                                    ALTO)</strong></p>
                                            <ol>
                                                <li>Pilih "Transaksi lainnya" + "Transaksi pembayaran"</li>
                                                <li>Pilih "Lainnya"</li>
                                                <li>Pilih "Pembayaran Virtual Account"</li>
                                                <li>Masukan nomor Virtual Account <strong> XXXXXX XXXXXX XXXX</strong>
                                                </li>
                                                <li>Masukan jumlah pembayaran yang sesuai dengan tagihan yang diberikan
                                                    (kesalahan input atas jumlah pembayaran dapat menyebabkan pesanan
                                                    anda dibatalkan secara otomatis) dan pastikan bahwa semua informasi
                                                    telah benar sebelum melakukan konfirmasi pembayaran</li>
                                                <li>Mohon simpan baik-baik bukti pembayaran anda</li>
                                                <li>Setelah transaksi anda dapat di verifikasi/ tervalidasi; sistem akan
                                                    mengirimkan E-voucher/ E-ticket anda dan selamat menikmati
                                                    pertunjukan yang ada</li>
                                            </ol>
                                            <p><strong>Petunjuk umum pembayaran dengan Virtual Account/ Akun Virtual
                                                    bank transfer (ATM BERSAMA/ PRIMA/ ALTO network)</strong></p>
                                            <ol>
                                                <li>Pilih pembayaran dengan Bank transfer/ Virtual Account</li>
                                                <li>Gunakan ATM dalam jaringan ATM BERSAMA/ PRIMA/ ALTO untuk
                                                    menyelesaikan transaksi anda</li>
                                                <li>Masukan PIN pada ATM anda, pilih transaksi "Lainnya" + "Transfer" +
                                                    "Bank lainnya/ Other bank"</li>
                                                <li>Masukan kode bank dan nomor Virtual Account <strong>013 XXXXXX
                                                        XXXXXX XXXX</strong></li>
                                                <li>Masukan jumlah pembayaran yang sesuai dengan tagihan yang diberikan
                                                    (kesalahan input atas jumlah pembayaran dapat menyebabkan pesanan
                                                    anda dibatalkan secara otomatis) dan pastikan bahwa semua informasi
                                                    telah benar sebelum melakukan konfirmasi pembayaran</li>
                                                <li>Mohon simpan baik-baik bukti pembayaran anda</li>
                                                <li>Setelah transaksi anda dapat di verifikasi/ tervalidasi; sistem akan
                                                    mengirimkan E-voucher/ E-ticket anda dan selamat menikmati
                                                    pertunjukan yang ada</li>
                                            </ol>
                                            <br>
                                            <form action="#" method="POST"
                                                id="payment-form-87">
                                                <input type="hidden" name="_token"
                                                    value="bGF86yP5lGvbOv0rfK1WUi7ym27YIBpyrqZ6IWW2">
                                                <input type="hidden"
                                                    value="eyJpdiI6Ik96dnBYMmRhSXJxVGpGNm1VeWk1RlE9PSIsInZhbHVlIjoic24rRTNVYTVrRFwvNnJ2VWFOZFlDTHBUalFORmVobzg3V1BVbmhWbjFhQm89IiwibWFjIjoiNmM5ZjJmMmUxYmI4ZGJiZmFjNGZjMDYwZmIyZWQwZDExZjBkZDI0ZjljYjY5MjFlMDEwNzc4NDAwYzZkODg2YyJ9"
                                                    name="key">
                                                <input type="hidden" value="87" name="payment_method_id">
                                                <input type="hidden" value="bank_transfer" name="payment_type">
                                                <input type="hidden" class="voucher_code" name="voucher_code">
                                                <input type="hidden" class="voucher_id" name="voucher_id">
                                                <input type="hidden" class="voucher_value" name="voucher_value">
                                                <input type="hidden" name="gross_amount" value="350000">
                                            </form>

                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="payment-92" data-typepyment="cstore"
                                        data-accuring="indomaret">
                                        <h4 class="panel-title">
                                            <a role="button" data-toggle="collapse"
                                                class="flex-center collapsed sectionBtn section-disable"
                                                data-parent="#accordion-payment" title="Indomaret"
                                                href="#payment-section-92" aria-expanded="true"
                                                aria-controls="ticket-section-92" title="Indomaret">
                                                Indomaret
                                                <img src="https://www.kiostix.com/images/cstore.png"
                                                    style="width: 79px; height: 20px;" alt="">
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="payment-section-92" class="panel-collapse collapse" role="tabpanel"
                                        aria-labelledby="92" title="Indomaret" data-typepyment="cstore"
                                        data-accuring="indomaret">
                                        <div class="panel-body">
                                            <h4>Cara pembayaran di Indomaret</h4>
                                            <ul>
                                                <li>Pergi ke Indomaret terdekat dan berikan Kode Pembayaran Anda ke
                                                    kasir</li>
                                                <li>Kasir Indomaret akan mengkonfirmasi transaksi dengan menanyakan
                                                    Jumlah Tagihan dan Nama Toko</li>
                                                <li>Bayar sesuai Jumlah Tagihan Anda</li>
                                                <li>Setelah pembayaran diterima, Anda akan menerima konfirmasi yang
                                                    dikirimkan ke email</li>
                                                <li>Simpanlah struk transaksi Indomaret Anda sebagai bukti pembayaran
                                                </li>
                                            </ul>
                                            <br>
                                            <form action="#" method="POST"
                                                id="payment-form-92">
                                                <input type="hidden" name="_token"
                                                    value="bGF86yP5lGvbOv0rfK1WUi7ym27YIBpyrqZ6IWW2">
                                                <input type="hidden"
                                                    value="eyJpdiI6IlRiNVY1RmZEaXA5RmhRVkM1T2NKVkE9PSIsInZhbHVlIjoiTTZ3eHJaeDFZM2g5SFFMV1cwK0dPV1NLTFNWWitWekdzTkZHRHRXUmRGbz0iLCJtYWMiOiIwOGE5MjlhZDFmMzBjMjkzNjkxMzgxN2ZhMDJlYjZjOWMzODUyN2E1N2YzOGNiZDYxMjI3ZDViYmJjNzEyNWFmIn0="
                                                    name="key">
                                                <input type="hidden" value="92" name="payment_method_id">
                                                <input type="hidden" value="cstore" name="payment_type">
                                                <input type="hidden" class="voucher_code" name="voucher_code">
                                                <input type="hidden" class="voucher_id" name="voucher_id">
                                                <input type="hidden" class="voucher_value" name="voucher_value">
                                                <input type="hidden" name="gross_amount" value="350000">
                                            </form>

                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="payment-93" data-typepyment="cimb_clicks"
                                        data-accuring="cimb">
                                        <h4 class="panel-title">
                                            <a role="button" data-toggle="collapse"
                                                class="flex-center collapsed sectionBtn section-disable"
                                                data-parent="#accordion-payment" title="CIMB Clicks"
                                                href="#payment-section-93" aria-expanded="true"
                                                aria-controls="ticket-section-93" title="CIMB Clicks">
                                                CIMB Clicks
                                                <img src="https://www.kiostix.com/images/cimb_clicks.png"
                                                    style="width: 79px; height: 20px;" alt="">
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="payment-section-93" class="panel-collapse collapse" role="tabpanel"
                                        aria-labelledby="93" title="CIMB Clicks" data-typepyment="cimb_clicks"
                                        data-accuring="cimb">
                                        <div class="panel-body">
                                            <h4>Cara pembayaran via CIMB Clicks</h4>
                                            <ul>
                                                <li>Masukkan user id di CIMB Clicks</li>
                                                </li>
                                                <li>Setelah redirect https://www.cimbclicks.co.id</li>
                                                <li>Pilih Source Account</li>
                                                <li>Cek Inbox SMS , anda akan menerima Code Pembayaran</li>
                                                <li>Masukkan Kode Pembayaran</li>
                                                <li>Tekan Tombol Submit</li>
                                            </ul>
                                            <br>
                                            <form action="#" method="POST"
                                                id="payment-form-93">
                                                <input type="hidden" name="_token"
                                                    value="bGF86yP5lGvbOv0rfK1WUi7ym27YIBpyrqZ6IWW2">
                                                <input type="hidden"
                                                    value="eyJpdiI6ImgxRHFkT296QlRhREZuMlZNSmswbUE9PSIsInZhbHVlIjoiVjBqOEVrQTlIMmxWd05qZm8rSTZCRisrTDFUU3RYRm1HaHRxTmRYSmlpQT0iLCJtYWMiOiJmOTU3ZTllNmI2MmZlMjU1MGMyZTM1MmQ3NWIwNGI4NThlMGYxZThiZWZiY2RlZjZjYjQwZDYwNDg2ZGE5NWFkIn0="
                                                    name="key">
                                                <input type="hidden" value="93" name="payment_method_id">
                                                <input type="hidden" value="cimb_clicks" name="payment_type">
                                                <input type="hidden" class="voucher_code" name="voucher_code">
                                                <input type="hidden" class="voucher_id" name="voucher_id">
                                                <input type="hidden" class="voucher_value" name="voucher_value">
                                                <input type="hidden" name="gross_amount" value="350000">
                                            </form>

                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="payment-1005" data-typepyment="echannel"
                                        data-accuring="mandiri">
                                        <h4 class="panel-title">
                                            <a role="button" data-toggle="collapse"
                                                class="flex-center collapsed sectionBtn section-disable"
                                                data-parent="#accordion-payment" title="Mandiri Bill Payment"
                                                href="#payment-section-1005" aria-expanded="true"
                                                aria-controls="ticket-section-1005" title="Mandiri Bill Payment">
                                                Mandiri Bill Payment
                                                <img src="https://www.kiostix.com/images/echannel.png"
                                                    style="width: 79px; height: 20px;" alt="">
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="payment-section-1005" class="panel-collapse collapse" role="tabpanel"
                                        aria-labelledby="1005" title="Mandiri Bill Payment" data-typepyment="echannel"
                                        data-accuring="mandiri">
                                        <div class="panel-body">
                                            <h4>Pembayaran via Mandiri Bill Payment</h4>
                                            <p>1. Pilih &ldquo;Transfer Bank&rdquo; pada halaman Metode Pembayaran, dan
                                                simpan 12-digit Kode Pembayaran Anda<br />2. Pada mesin ATM, pilih
                                                &ldquo;Pembayaran&rdquo;, kemudian pilih &ldquo;Lainnya&rdquo;<br />3.
                                                Pilih &ldquo;Multi Payment&rdquo;<br />4. Masukkan Kode Perusahaan 70012
                                                (Midtrans), dan tekan &ldquo;Benar&rdquo;<br />5. Masukkan 12-digit Kode
                                                Pembayaran dan tekan &ldquo;Benar&rdquo;<br />6. Pilih nomor 1 dan tekan
                                                &ldquo;Ya&rdquo; untuk melanjutkan pembayaran<br />7. Cek kembali
                                                rangkuman transaksi untuk konfirmasi pembayaran, tekan &ldquo;Ya&rdquo;
                                                untuk melanjutkan<br />8. Simpan bukti pembayaran Anda<br />9. Setelah
                                                pembayaran Anda diverifikasi, sistem kami secara otomatis akan
                                                mengirimkan E-Voucher Anda melalui email.</p>
                                            <p><br /><em><strong>Payment using Mandiri Bill Payment</strong></em></p>
                                            <p><em>1. Choose "Bank Transfer" or "Payment using ATM Mandiri" on Payment
                                                    Method page</em><br /><em>2. On ATM Mandiri, select "Payment", and
                                                    then "Other Payment"</em><br /><em>3. Select "Multi
                                                    Payment"</em><br /><em>4. Enter Institution Code : 70012 (Midtrans),
                                                    and press "Yes"</em><br /><em>5. Enter 12-digits Payment Code and
                                                    press "Yes"</em><br /><em>6. Select number 1 and press "Yes" to
                                                    proceed</em><br /><em>7. Check your summary to confirm your
                                                    transaction, press "Yes" to continue</em><br /><em>8. Keep your
                                                    transaction receipt / proof of payment</em><br /><em>9. When your
                                                    payment is verified / validated, our system will automatically send
                                                    you the E-Voucher via email.</em></p>
                                            <br>
                                            <form action="#" method="POST"
                                                id="payment-form-1005">
                                                <input type="hidden" name="_token"
                                                    value="bGF86yP5lGvbOv0rfK1WUi7ym27YIBpyrqZ6IWW2">
                                                <input type="hidden"
                                                    value="eyJpdiI6InFUekt6SHIrblVvOTFDUnM1RGx0K1E9PSIsInZhbHVlIjoiVmR4N2xZZW5DdlwvbWtRSjc2U2xhRWZnWkZwOFFFanMyT1Z0R3ZIYjNyamc9IiwibWFjIjoiNmNkNzZhNmM3ZGFjNmIwNjhiMzM5YTJkMDY5YzI4MDljNjcyMzUxNWZiN2IwZjY3OTRiMjA1MmI3MGJlODFlMSJ9"
                                                    name="key">
                                                <input type="hidden" value="1005" name="payment_method_id">
                                                <input type="hidden" value="echannel" name="payment_type">
                                                <input type="hidden" class="voucher_code" name="voucher_code">
                                                <input type="hidden" class="voucher_id" name="voucher_id">
                                                <input type="hidden" class="voucher_value" name="voucher_value">
                                                <input type="hidden" name="gross_amount" value="350000">
                                            </form>

                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="payment-1026" data-typepyment="tcash"
                                        data-accuring="">
                                        <h4 class="panel-title">
                                            <a role="button" data-toggle="collapse"
                                                class="flex-center collapsed sectionBtn section-disable"
                                                data-parent="#accordion-payment" title="TCASH"
                                                href="#payment-section-1026" aria-expanded="true"
                                                aria-controls="ticket-section-1026" title="TCASH">
                                                TCASH
                                                <img src="https://www.kiostix.com/images/tcash.png"
                                                    style="width: 79px; height: 20px;" alt="">
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="payment-section-1026" class="panel-collapse collapse" role="tabpanel"
                                        aria-labelledby="1026" title="TCASH" data-typepyment="tcash" data-accuring="">
                                        <div class="panel-body">
                                            <form action="#" method="POST"
                                                id="payment-form-1026">
                                                <input type="hidden" name="_token"
                                                    value="bGF86yP5lGvbOv0rfK1WUi7ym27YIBpyrqZ6IWW2">
                                                <input type="hidden"
                                                    value="eyJpdiI6IkFwaXpmRXVVcUdCeDlJZ3lCSTcyZFE9PSIsInZhbHVlIjoidE9uV0xnXC9EaDhxXC9VQjdhMTl5YTJEaklNYWRNV1lVZ3R4RjZTN1V5dEVRPSIsIm1hYyI6ImVkOTZmYjUyNTNhMGI0Mjg2M2Y4ZDcyMTYyNjg3NjAyMWY5ZmQ1YzhmNjIxMGU5N2EyYTZiMGM3MjIwMzU2NmYifQ=="
                                                    name="key">
                                                <input type="hidden" value="1026" name="payment_method_id">
                                                <input type="hidden" value="tcash" name="payment_type">
                                                <input type="hidden" class="voucher_code" name="voucher_code">
                                                <input type="hidden" class="voucher_id" name="voucher_id">
                                                <input type="hidden" class="voucher_value" name="voucher_value">
                                                <input type="hidden" name="message">
                                                <input type="hidden" name="gross_amount" value="350000">
                                            </form>
                                            <p><span style="font-weight: 400;">Berikut adalah Step Payment melalui TCASH
                                                    :</span></p>
                                            <ol>
                                                <li style="font-weight: 400;">Masukkan nomor telepon Anda, PIN TCASH,
                                                    dan captcha (bersyarat). Setelah itu klik tombol "Lanjutkan".</li>
                                                <li style="font-weight: 400;">Anda akan mendapatkan SMS dari kode
                                                    verifikasi yang akan dikirim ke nomor telepon Anda, masukkan di
                                                    halaman check out. Setelah itu periksa pada formulir perjanjian dan
                                                    klik tombol "Proses".</li>
                                                <li style="font-weight: 400;">Jika pembayaran berhasil, Anda akan
                                                    menerima konfirmasi SMS.</li>
                                            </ol>

                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="payment-1045" data-typepyment="gopay"
                                        data-accuring="gopay">
                                        <h4 class="panel-title">
                                            <a role="button" data-toggle="collapse"
                                                class="flex-center collapsed sectionBtn section-disable"
                                                data-parent="#accordion-payment" title="GOPAY"
                                                href="#payment-section-1045" aria-expanded="true"
                                                aria-controls="ticket-section-1045" title="GOPAY">
                                                GOPAY
                                                <img src="https://www.kiostix.com/images/gopay.png"
                                                    style="width: 79px; height: 20px;" alt="">
                                            </a>
                                        </h4>
                                    </div>
                                    <div id="payment-section-1045" class="panel-collapse collapse" role="tabpanel"
                                        aria-labelledby="1045" title="GOPAY" data-typepyment="gopay"
                                        data-accuring="gopay">
                                        <div class="panel-body">
                                            <p>1. Click &ldquo;Bayar menggunakan GOPAY&rdquo;<br />2. Open your GO-JEK
                                                Application in your device<br />3. Click Pay<br />4. Point your device
                                                camera to the QR Code on the screen<br />5. Check your payment details
                                                in your GO-JEK Application and press Pay<br />6. Your transaction is
                                                completed</p>
                                            <br>
                                            <form action="<?php echo base_url() ?>checkout/simpan" method="POST"
                                                id="payment-form-1045">
                                                <input type="hidden" value="gopay" name="metode_pembayaran">
                                                <input type="hidden" value="<?php echo $user['id']?>" name="id_user">
                                                <input type="hidden" value="<?php echo $bayar['id']?>" name="id_pembayaran">
                                                <input type="hidden" value="<?php echo $event['id']?>" name="id_event">
                                                <input type="submit" id="submit-form" class="hidden" />
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="loading loading-double hide" id="loader-payment"></div>
                            <div id="btnPayBox">
                                <label for="submit-form" class="button btn-block btn-add btnPay">Bayar Sekarang</label>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
