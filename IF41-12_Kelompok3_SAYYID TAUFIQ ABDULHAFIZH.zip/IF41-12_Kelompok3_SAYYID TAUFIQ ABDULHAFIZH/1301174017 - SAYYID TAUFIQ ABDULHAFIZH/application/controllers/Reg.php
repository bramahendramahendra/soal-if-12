<?php
 // Sarwan Muharram 1301174168
class Reg extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Mreg');
		$this->load->library("form_validation");
	}

	public function index()
	{
		redirect('home');
	}

	public function tambah()
	{
		// echo $this->input->post('email_conf');
		// echo $this->input->post('email');
		// echo $this->input->post('pass');
		// echo $this->input->post('pass_conf');
		// $this->form_validation->set_rules('email', 'Email','required|valid_email|matches[email_conf]');
		// $this->form_validation->set_rules('pass', 'Pass','required|matches[pass_conf]');
		// echo $this->form_validation->run();
		// if ($this->form_validation->run() == false) {
		// 	$this->session->set_flashdata('message', 'error_not_match');
		// 	redirect('home');
		// }else{
		// 	$this->Mreg->tambahDataUser();
		// 	$this->session->set_flashdata('message', 'success');
		// 	redirect('home');
		// }
            if ($this->input->post('email')!=$this->input->post('email_conf')){
				$this->session->set_flashdata('message', 'error_not_match');
                redirect('home');
			}
			if ($this->input->post('pass')!=$this->input->post('pass_conf')){
				$this->session->set_flashdata('message', 'error_not_match');
                redirect('home');
			}
			$this->Mreg->tambahDataUser();
			$this->session->set_flashdata('message', 'success');
			redirect('home');
        
	}
}
