<?php
class Event extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
        $this->load->model('Muser');
		$this->load->model('Mevent');
        $this->load->model('Mreg');
        $this->load->library("form_validation");
        if ($this->session->userdata('status') != "admin") {
            redirect('admin/login');
        }
	}

	public function index()
	{
		$data['judul'] = 'Daftar Event';
		$data['event'] = $this->Mevent->getAllEvent();
		if ($this->input->post('keyword')) {
			$data['event'] = $this->Mevent->cariDataEvent();
		}
		$this->load->view('layouts/header-admin', $data);
		$this->load->view('admin/event/event', $data);
		$this->load->view('layouts/footer-admin');
    }
    
	public function tambah()
	{
        
		$data['judul'] = 'Tambah Event';
		$this->load->view('layouts/header-admin', $data);
		$this->load->view('admin/event/tambah', $data);
		$this->load->view('layouts/footer-admin');
	}

	public function simpan()
	{
        $config['upload_path']          = './images/';
		$config['allowed_types']        = 'gif|jpg|png';
		$config['max_size']             = 5000;
		$config['max_width']            = 5000;
		$config['max_height']           = 5000;
 
		$this->load->library('upload', $config);
 
		if ( ! $this->upload->do_upload('berkas')){
            $this->session->set_flashdata('message', 'error_not_match');
			redirect('event/tambah');
			echo "error";
		}else{
			$this->Mevent->tambahDataEvent($data);
            $this->session->set_flashdata('message', 'success');
            redirect('event');
        }
	}
	
	public function ubah($id)
	{
		$data['judul'] = 'Form Ubah Data Event';

		$data['event'] = $this->Mevent->getEventById($id);

		$this->form_validation->set_rules('judul', 'Judul','required');

		if ($this->form_validation->run() == false) {
			$this->load->view('layouts/header-admin', $data);
			$this->load->view("admin/event/ubah", $data);
			$this->load->view('layouts/footer-admin');
		}else{
            $config['upload_path']          = './images/';
            $config['allowed_types']        = 'gif|jpg|png';
            $config['max_size']             = 5000;
            $config['max_width']            = 2058;
            $config['max_height']           = 1152;
    
            $this->load->library('upload', $config);
    
            if ( ! $this->upload->do_upload('berkas')){
                // echo "nofoto baru";
                $file_name = $data['event']['foto'];
                $this->Mevent->ubahDataEvent($id, $file_name);
                $this->session->set_flashdata('flash','changed success');
                redirect('event');
            }else{
                echo "foto baru";
                $upload_data = $this->upload->data();
                $file_name = $upload_data['file_name'];
                $this->Mevent->ubahDataEvent($id, $file_name);
                $this->session->set_flashdata('flash','changed success');
                redirect('event');
            }
		}
		}
		
	public function lihat($id)
	{
		$data['judul'] = 'Form Ubah Data Event';
		$data['event'] = $this->Mevent->getEventById($id);
		$this->load->view('layouts/header-admin', $data);
		$this->load->view('admin/event/lihat', $data);
		$this->load->view('layouts/footer-admin');
	}
    
    public function hapus($id)
	{
		$this->Mevent->hapusDataEvent($id);
		$this->session->set_flashdata('message', 'dihapus');
		redirect('event');

	}
}