<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mevent extends CI_Model {

	public function Getevent(){
		$this->db->select('*');
		$this->db->from('event');
		$query = $this->db->get();
		return $query->result();
	}

  public function Get1($id){
		$this->db->where('');

	}


	function hapus_event($where,$table){
	$this->db->where($where);
	$this->db->delete($table);
}

public function edit_event($id,$data)
{
	$this->db->where('id', $id);
	$this->db->update('event', $data);
		return;
}

  public function tambah_event($data)
	{
		$this->db->insert('event',$data);
			return;
	}

	public function getAllEvent()
	{
		
		return $this->db->get("event")->result_array();

    }
    
    public function cariDataEvent()
	{
		$keyword = $this->input->post('keyword', true);
		$this->db->like('judul', $keyword, 'both');
		$this->db->or_like('tempat', $keyword, 'both');
		$this->db->or_like('harga', $keyword, 'both');
		return $this->db->get('event')->result_array();
    }
	
	public function tambahDataEvent()
	{
		$upload_data = $this->upload->data();
		$file_name = $upload_data['file_name'];
		$data = [
			"judul" => $this->input->post('judul', true),
			"tanggal" => $this->input->post('tanggal', true),
			"waktu" => $this->input->post('waktu', true),
			"tempat" => $this->input->post('tempat', true),
			"deskripsi" => $this->input->post('deskripsi', true),
			"harga" => $this->input->post('harga', true),
			"foto" => $file_name,
			"jumlah" => $this->input->post('jumlah', true),
			"tag" => $this->input->post('tag', true),
			"jenis_tiket" => $this->input->post('jenis_tiket', true),
		];
		$this->db->insert('event', $data);
	}
	
    public function hapusDataEvent($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('event');
	}

	public function getEventById($id)
	{
		$this->db->where('id', $id);
		return $this->db->get('event')->row_array();

	}

	public function ubahDataEvent($id, $file_name)
	{
		$data = [
			"judul" => $this->input->post('judul', true),
			"tanggal" => $this->input->post('tanggal', true),
			"waktu" => $this->input->post('waktu', true),
			"tempat" => $this->input->post('tempat', true),
			"deskripsi" => $this->input->post('deskripsi', true),
			"harga" => $this->input->post('harga', true),
			"foto" => $file_name,
			"jumlah" => $this->input->post('jumlah', true),
			"tag" => $this->input->post('tag', true),
			"jenis_tiket" => $this->input->post('jenis_tiket', true),
		];
		$this->db->where('id', $id);
		return $this->db->update('event', $data);
	}

}
