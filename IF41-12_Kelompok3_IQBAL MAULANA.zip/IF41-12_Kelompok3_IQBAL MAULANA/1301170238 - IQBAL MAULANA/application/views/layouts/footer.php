<footer>
    <section class="footer-top">
        <div class="container">
            <div class="row">
                <div class="col-md-3">
                    <div class="widget">
                        <div class="widget-title">
                            <h3>Bantuan</h3>
                        </div>
                        <div class="widget-content">
                            <ul>
                                <li><a href="#">F.A.Q.</a></li>
                                <li><a href="#">Kebijakan Privasi</a></li>
                                <li><a href="#">Syarat &amp; Ketentuan</a></li>
                                <li><a href="#">Daftarkan Acara Kamu</a></li>
                                <li><a href="#">Hubungi Kami</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="widget">
                        <div class="widget-title">
                            <h3>kiosTix</h3>
                        </div>
                        <div class="widget-content">
                            <ul>
                                <li><a href="#">Tentang KiosTix</a></li>
                                <li><a href="#">Karir - We Hiring!</a></li>
                                <li><a href="#">Produk &amp; Layanan</a></li>
                                <li><a href="#">Majalah</a></li>
                            </ul>
                        </div>
                    </div>
                </div>

                <div class="col-md-3">
                    <div class="widget">
                        <div class="widget-title">
                            <h3>Ikuti Kami</h3>
                        </div>
                        <div class="widget-content">
                            <div class="socmed">
                                </a>
                                <a href="#" target="_blank"><i class="icon ion-logo-instagram"></i></a>
                                <a href="#" target="_blank"><i class="icon ion-logo-facebook"></i></a>
                                <a href="#" target="_blank"><i class="icon ion-logo-twitter"></i></i></a>
                                <a href="#" target="_blank"><i class="icon ion-logo-youtube"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="footer-bottom">
        <div class="container flex-center">
            <p class="copy">Copyright 2019 &copy; All Right Reserved. kiostix.com</p>
        </div>
    </section>
</footer>
</div>
</body>

</html>