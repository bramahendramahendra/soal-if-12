<!doctype html>
<html lang="en">

<head>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.2.1/css/bootstrap.min.css">
    <link href="https://unpkg.com/ionicons@4.5.5/dist/css/ionicons.min.css" rel="stylesheet">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mouse0270-bootstrap-notify/3.1.5/bootstrap-notify.min.js"></script>
    <title><?php echo $judul ?></title>
</head>

<body>
    <?php
            $message = $this->session->flashdata('message');
            if ($message == "success") {
                ?>
    <script type="text/javascript">
    $(document).ready(function() {
        $.notify({
            title: '<strong>SUCCESS</strong>',
            icon: 'icon ion-md-done',
            message: "Create has been success!"
        }, {
            type: 'success',
            animate: {
                enter: 'animated fadeInUp',
                exit: 'animated fadeOutRight'
            },
            placement: {
                from: "bottom",
                align: "right"
            },
            offset: 20,
            spacing: 10,
            z_index: 1031,
        });
    });
    </script>
    <?php
        };
        ?>
    <?php
        $message = $this->session->flashdata('message');
        //   echo "$message";
        if ($message == "error_not_match") {
            ?>
    <script type="text/javascript">
    $(document).ready(function() {
        $.notify({
            title: '<strong>ERROR</strong>',
            icon: 'icon ion-md-alert',
            message: "Data Error, please try again!"
        }, {
            type: 'danger',
            animate: {
                enter: 'animated fadeInUp',
                exit: 'animated fadeOutRight'
            },
            placement: {
                from: "bottom",
                align: "right"
            },
            offset: 20,
            spacing: 10,
            z_index: 1031,
        });
    });
    </script>
    <?php
            };
            ?>
    <?php
            $message = $this->session->flashdata('message');
            if ($message == "dihapus") {
                ?>
    <script type="text/javascript">
    $(document).ready(function() {
        $.notify({
            title: '<strong>SUCCESS</strong>',
            icon: 'icon ion-md-done',
            message: "Delete has been success!"
        }, {
            type: 'success',
            animate: {
                enter: 'animated fadeInUp',
                exit: 'animated fadeOutRight'
            },
            placement: {
                from: "bottom",
                align: "right"
            },
            offset: 20,
            spacing: 10,
            z_index: 1031,
        });
    });
    </script>
    <?php
        };
        ?>
    <?php
            $message = $this->session->flashdata('message');
            if ($message == "changed success") {
                ?>
    <script type="text/javascript">
    $(document).ready(function() {
        $.notify({
            title: '<strong>SUCCESS</strong>',
            icon: 'icon ion-md-done',
            message: "Change data has been success!"
        }, {
            type: 'success',
            animate: {
                enter: 'animated fadeInUp',
                exit: 'animated fadeOutRight'
            },
            placement: {
                from: "bottom",
                align: "right"
            },
            offset: 20,
            spacing: 10,
            z_index: 1031,
        });
    });
    </script>
    <?php
        };
        ?>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container">
            <a class="navbar-brand" href="<?= base_url(); ?>"><img src="<?= base_url(); ?>/assets/img/logo.png"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-item nav-link" href="<?= base_url(); ?>">Home</a>
                    <a class="nav-item nav-link" href="<?= base_url(); ?>event">Events</a>
                    <a class="nav-item nav-link" href="<?= base_url(); ?>user">Users</a>
                </div>
            </div>
        </div>
        <div class="navbar-nav mr-sm-2" style="position: relative;right: 200px">
            <a class="nav-item nav-link" href="">
                Hi, <?php echo $this->session->userdata('nama')?></a>
            <a class="nav-item nav-link" href="<?php echo base_url() ?>Admin/logout">Log out</a>
        </div>
    </nav>