</header>
<main>
    <section id="search" class="page-id">
        <div class="header-search bgcover">
            <div class="container">
                <div id="searchbox">
                    <h2>Temukan acara dan kegiatan seru di kiosTix!</h2>
                    <div>
                        <form method="GET" action="#" accept-charset="UTF-8"
                            class="searchform typeahead" role="search">
                            <input type="text" name="q" value="" class="input-search search-input"
                                placeholder="Cari event kamu di sini" autocomplete="off">
                            <button type="submit" class="btn-search" name="submit"><i
                                    class="ion-ios-search-strong"></i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section id="section-home" class="section">
        <div class="container">
            <div class="titleBox flex flex-center">
                <h2 class="title" id="titleFilters">Events</h2>
            </div>
            <div class="theContents Events">
                <div class="scroll">
                    <div id="data" class="event-list">
                        <?php //perbaiki baris ini ) {?>
                        <a href="<?php echo base_url() ?>eve/detailevent/<?= $d->id ?>" class="eventBox">
                            <div class="event-box box flex-center">
                                <div class="event-image thumb thumb-small">
                                    <img class="img-thumbnail center-block"
                                        src="<?php echo base_url('images/').$d->foto ?>" width="1000px">
                                </div>
                                <div class="event-information">
                                    <div class="event-entry">
                                        <h3><?php echo $d->judul ?></h3>
                                        <span class="date start-date"><?php echo $d->tanggal ?></span>
                                        <div class="event-venue">
                                            <?php echo $d->tempat ?>
                                            </span>
                                        </div>
                                    </div>

                                </div>
                            </div>
                        </a>


                        <?php } ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
</main>
