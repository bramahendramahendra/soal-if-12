<?php
        $message = $this->session->flashdata('message');
        //   echo "$message";
        if ($message == "quantity_zero") {
            ?>
    <script type="text/javascript">
    $(document).ready(function() {
        $.notify({
            title: '<strong>ERROR</strong>',
            icon: 'icon ion-md-alert',
            message: "Jumlah Tiket Kosong!"
        }, {
            type: 'danger',
            animate: {
                enter: 'animated fadeInUp',
                exit: 'animated fadeOutRight'
            },
            placement: {
                from: "bottom",
                align: "right"
            },
            offset: 20,
            spacing: 10,
            z_index: 1031,
        });
    });
    </script>
    <?php
            };
            ?>
<div class="container" style="margin-top: 2%; margin-bottom: 2%">
    <div class="row">
        <div class="col-md-12">
            <div class="event-meta">
                <h1><?php echo $event['judul']?></h1>
            </div>
        </div>
        <div class="col-md-6">
            <div class="event-entry">
                <div class="event-image thumb">
                    <img src="<?php echo base_url() ?>images/<?php echo $event['foto']?>">
                </div>
                <div class="collapse in" id="eventview">
                    <div class="event-detail">
                        <ul class="nav nav-tabs" role="tablist">
                            <li role="presentation" class="active"><a href="#details" aria-controls="details" role="tab"
                                    data-toggle="tab">Details</a></li>
                            <li role="presentation"><a href="#tnc" aria-controls="tnc" role="tab"
                                    data-toggle="tab">Syarat dan Ketentuan yang berlaku.</a></li>
                        </ul>
                        <div class="tab-content">
                            <div role="tabpanel" class="tab-pane active" id="details">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="event-info event-artist flex">
                                            <label>Tag :</label>
                                            <div class="artists">
                                                <?php 
                                                    $myArray = explode(',', $event['tag']);
                                                    foreach ($myArray as $d) {
                                                ?>
                                                <a class="venue-name" href="#"><?php echo $d ?></a>
                                                <?php } ?>
                                            </div>
                                        </div>
                                        <div class="event-info event-venue flex">
                                            <label>Lokasi :</label>
                                            <div class="venues">
                                                <div class="the-schedule-list">
                                                    <a class="venue-name" href=""><?php echo $event['tempat']?></a>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="event-info event-venue flex">
                                            <label>Tanggal :</label>
                                            <div class="venues">
                                                <a class="venue-name"><?php echo date("l", strtotime($event['tanggal'])) ?>,
                                                    <?php echo date("d F Y",strtotime($event['tanggal']))?></a>
                                            </div>
                                        </div>
                                    </div>

                                </div>
                                <div class="event-description">
                                    <p style="text-align: justify;"><span
                                            style="font-weight: 400;"><?php echo nl2br($event['deskripsi'])?></span></p>
                                </div>
                            </div>
                            <div role="tabpanel" class="tab-pane" id="tnc">
                                <p style="text-align: justify;">Setelah menyelesaikan pembelian di situs web dan outlet
                                    kami, Anda akan menerima E-voucher kiosTix yang langsung dikirim ke e-mail Anda.</p>
                                <p style="text-align: justify;">&nbsp;<br> <strong>Tukarkan tiket Anda sesuai jadwal di
                                        bawah ini:</strong></p>
                                <table style="width: 542px;">
                                    <tbody>
                                        <tr style="height: 19.8945px;">
                                            <td style="width: 108px; height: 19.8945px;">Tanggal</td>
                                            <td style="width: 25.7969px; height: 19.8945px;">&nbsp;:</td>
                                            <td style="width: 501.203px; height: 19.8945px;">
                                                <?php echo date("d F Y",strtotime($event['tanggal']))?></td>
                                        </tr>
                                        <tr style="height: 22px;">
                                            <td style="width: 108px; height: 22px;">Lokasi</td>
                                            <td style="width: 25.7969px; height: 22px;">&nbsp;:</td>
                                            <td style="width: 501.203px; height: 22px;"><?php echo $event['tempat']?>
                                            </td>
                                        </tr>
                                        <tr style="height: 22px;">
                                            <td style="width: 108px; height: 22px;">Persyaratan&nbsp;</td>
                                            <td style="width: 25.7969px; height: 22px;">&nbsp;:</td>
                                            <td style="width: 501.203px; height: 22px;">Membawa e-voucher dan kartu
                                                identitas yang terdaftar</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="widget-options">
                <div class="widget widget-box widget-schedule">
                    <form id="order-form-1841" class="orderFormd" method="POST"
                        action="<?php echo base_url() ?>checkout/pesan">
                        <input type="hidden" name="id" value="<?php echo $event['id']?>">
                        <input type="hidden" name="harga" value="<?php echo $event['harga']?>">
                        <a class="chooseTicket widget-list flex-center" data-toggle="collapse"
                            href="#section-schedule-1841" aria-expanded="false" aria-controls="section-schedule-1841">
                            <div class="colom-left">
                                <h4 class="schedule-name"><?php echo $event['judul']?></h4>
                                <span>
                                    <?php echo $event['tempat']?></span>
                                <br>
                                <span class="date start-date"><?php echo date("l", strtotime($event['tanggal'])) ?>,
                                    <?php echo date("d F Y",strtotime($event['tanggal']))?> |
                                    <?php echo $event['waktu']?>
                                </span>

                                <div id="time-schedule-1841" class="times session" data-toggle="tooltip"
                                    data-placement="top" title="Please select the event time, before find ticket.">
                                    <input class="radio-session hide" checked="" type="radio" session="1831"
                                        value="19:00:00" name="visit_time" id="session-1831">
                                </div>
                            </div>
                            <div class="colom-right">

                                <input type="hidden" name="schedule" value="1841">
                                <input type="hidden" name="visit_date" value="28 Apr 2019">
                            </div>
                        </a>
                        <div class="section-box collapse  in single-schedule " id="section-schedule-1841">
                            <div class="booking-header flex-center">
                                <div class="colom-info col3">
                                    <span>Harga/Section</span>
                                </div>
                                <div class="colom-left col3 center">
                                    <span>Kuantitas</span>
                                </div>
                                <div class="colom-right col3 text-right">
                                    <span>Subtotal</span>
                                </div>
                            </div>
                            <div class="booking-body" id="booking-body-1841">

                                <div class="row-section-ticket" id="section-schedule-ticket-8609">
                                    <div class="section-name col3">
                                        <span class="labels ticket-name">
                                            <?php echo $event['jenis_tiket']?>
                                        </span>
                                    </div>
                                    <div class="flex-center">
                                        <div class="colom-info col3">
                                            <span class="price ticket-price" id="section-price-8609">
                                                Rp.<?php echo number_format($event['harga'] , 0, ',', '.');?>
                                            </span>
                                        </div>
                                        <div class="colom-left col3 flex-center">
                                            <div class="input-group order-qty">
                                                <input type="button"
                                                    class="btn btn-default btn-number btn-calculate secondary" value="-"
                                                    id="minus" />
                                                <input type="text"
                                                    class="form-control input-number cat_textbox quantity" id="quantity"
                                                    value="0" name="quantity" />
                                                <input type="button"
                                                    class="btn btn-default btn-number btn-calculate secondary" value="+"
                                                    id="plus" />

                                            </div>
                                        </div>
                                        <div class="colom-right" id="subtotal-8609">
                                            Rp.
                                            <span id="total-price" class="product-price subtotal-price"
                                                value="0">0</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <script>
                            $('#plus').click(function add() {
                                var $qtde = $("#quantity");
                                var a = $qtde.val();

                                a++;
                                $("#minus").attr("disabled", !a);
                                $qtde.val(a);
                            });
                            $("#minus").attr("disabled", !$("#quantity").val());

                            $('#minus').click(function minust() {
                                var $qtde = $("#quantity");
                                var b = $qtde.val();
                                if (b >= 1) {
                                    b--;
                                    $qtde.val(b);
                                } else {
                                    $("#minus").attr("disabled", true);
                                }
                            });

                            $(document).ready(function() {
                                function updatePrice() {
                                    var price = parseFloat($("#quantity").val());
                                    var total = (price) * <?php echo $event['harga']; ?>;
                                    var total = total.toLocaleString();
                                    document.getElementById("total-price").innerHTML = total;
                                    document.getElementById("total-price2").innerHTML = total;
                                    // $("#total-price").val(total);
                                }
                                $(document).on("click", "input", updatePrice);
                            });
                            </script>

                            <div id="booking-detail-1841" class="booking-detail">
                                <div class="booking-footer">
                                    <div class="item-row booking-section">
                                        <span class="product-item">Total</span>
                                        <span class="product-price total-price">Rp.
                                            <span id="total-price2" value="0">0</span>
                                        </span>
                                    </div>
                                    <?php 
                                        if ($this->session->userdata('status') == "login") {
                                        ?>
                                        <button type="submit" class="button btn-block submitOrder showPopup" >Pesan
                                            Sekarang</button>
                                        <?php
                                        }else{
                                            ?>
                                        <a href="#popup-login" class="button btn-block submitOrder showPopup"
                                            data-toggle="modal" data-target="#myModal">
                                            <span>Pesan
                                            Sekarang</span>
                                        </a>   
                                        <?php } ?>
                                        <div class="loading loading-double hide" id="loader-order-1841"></div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>