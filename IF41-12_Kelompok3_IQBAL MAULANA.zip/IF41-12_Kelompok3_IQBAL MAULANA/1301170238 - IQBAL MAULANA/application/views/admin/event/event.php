<div class="container">
    <!-- <?php if ($this->session->flashdata('flash')) : ?>
    <div class="row mt-3">
        <div class="col-md-6">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                Event <strong>berhasil</strong> <?= $this->session->flashdata('flash'); ?>.
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    </div>
    <?php endif; ?> -->


    <div class="row mt-3">
        <div class="col md-6">
            <form action="" method="post">
                <div class="input-group">
                    <input type="text" class="form-control" style="border-radius: 0" placeholder="Cari event ... " name="keyword">
                    <div class="input-group-append">
                        <button class="btn btn-primary" style="background-color: #ea9a3f;border-color: #ea9a3f;border-radius: 0" type="submit">Cari</button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <div class="row mt-5">
        <div class="col">
            <h3 class="text-center">Daftar Event</h3>
            <?php if (empty($event)) : ?>
            <div class="alert alert-danger" role="alert">
                Data tidak ditemukan
            </div>
            <?php endif; ?>

            <table class="table mt-5">
                <thead>
                    <tr>
                        <th class="text-center" scope="col">JUDUL</th>
                        <th class="text-center" scope="col">TANGGAL</th>
                        <th class="text-center" scope="col">TEMPAT</th>
                        <th class="text-center" scope="col">JUMLAH</th>
                        <th class="text-center" scope="col">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <tr><?php foreach ($event as $usr) : ?>
                        <td class="text-center"><?= $usr['judul']; ?></td>
                        <td class="text-center"><?= $usr['tanggal']; ?></td>
                        <td class="text-center"><?= $usr['tempat']; ?></td>
                        <td class="text-center"><?= $usr['jumlah']; ?></td>
                        <td class="text-center">
                            <a href="<?= base_url(); ?>event/lihat/<?= $usr['id'] ?>" class="icon ion-md-eye" ?></a>
                            <a href="<?= base_url(); ?>event/ubah/<?= $usr['id'] ?>" class="icon ion-md-create" ?></a>
                            <a href="<?= base_url(); ?>event/hapus/<?= $usr['id'] ?>" class="icon ion-md-trash" onclick="return confirm('Apakah anda yakin menghapus event ini?');" ?></a>
                        </td>
                    </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
            <div class="row mt-3">
                <div class="col md-6 text-center mt-5">

                    <a href="<?= base_url(); ?>event/tambah " class="btn btn-primary" style="background-color: #ea9a3f;border-color: #ea9a3f;border-radius: 10px">Tambah Event</a>
                </div>
            </div>

        </div>
    </div>
</div> 