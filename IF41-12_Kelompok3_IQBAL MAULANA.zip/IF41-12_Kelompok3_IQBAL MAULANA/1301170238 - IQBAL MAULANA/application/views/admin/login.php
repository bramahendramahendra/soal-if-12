<html>

<head>
    <link href="<?php echo base_url() ?>/assets/css/bootstrap4.css" rel="stylesheet" id="bootstrap-css">
    <script src="<?php echo base_url() ?>assets/js/bootstrap.js"></script>
    <script src="<?php echo base_url() ?>/assets/js/jquery.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mouse0270-bootstrap-notify/3.1.5/bootstrap-notify.min.js"></script>
    <style>
    .bg {
        background-image: url('<?php echo base_url() ?>/assets/img/bg-login.jpg');
        background-position: center;
        background-repeat: no-repeat;
        background-size: cover;
        color: white;
    }
    </style>
</head>

<body class="bg">
<?php
    $message = $this->session->flashdata('message');
    //   echo "$message";
    if ($message == "error") {
        ?>
    <script type="text/javascript">
    $(document).ready(function() {
        $.notify({
            title: '<strong>ERROR</strong>',
            icon: 'icon ion-md-alert',
            message: "Email or Password wrong!"
        }, {
            type: 'danger',
            animate: {
                enter: 'animated fadeInUp',
                exit: 'animated fadeOutRight'
            },
            placement: {
                from: "bottom",
                align: "right"
            },
            offset: 20,
            spacing: 10,
            z_index: 1031,
        });
    });
    </script>
    <?php
        };
        ?>
    <div class="container">
        <div class="row">
            <form class="col" role="form" method="POST" action="<?php echo base_url() ?>Admin/masuk">
                <h3 style="margin-top :10%; text-align: center;">Login Admin</h3>
                <hr class="divisor">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" name="email"
                        placeholder="Enter email">
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" name="password" id="password" placeholder="Password">
                </div>
                <!-- <div class="form-check">
                    <input type="checkbox" class="form-check-input" id="checkbox">
                    <label class="form-check-label" for="exampleCheck1">Remember me</label>
                </div> -->
                <button type="submit" class="btn btn-primary"><i class="fa fa-sign-in"></i> Sign in</button>
            </form>
        </div>
    </div>
</body>

</html>