<?php

class Home extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Mevent');
	}

	public function index()
	{
	$data_event = $this->Mevent->Getevent();
	$this->load->view('layouts/header');
	$this->load->view('index',['data'=>$data_event]);
        $this->load->view('layouts/footer');
	}
}