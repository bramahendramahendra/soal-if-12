<?php
 // Sarwan Muharram 1301174168
class Mlog extends CI_model
{
	public function getAllUser()
	{
		$this->db->select('*');
		$this->db->from('register');
		$getm = $this->db->get();
		return $getm->result_array();
	}

	public function cekDataUser($email,$pass)
	{
        $this->db->where('email',$email);
        $this->db->where('pass',$pass);
				return $this->db->get('register')->row_array();
	}
}
