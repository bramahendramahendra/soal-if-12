<?php
 // Sarwan Muharram 1301174168
class Muser extends CI_model
{
	public function getAllUser()
	{
		
		return $this->db->get("register")->result_array();

    }
    
    public function cariDataUser()
	{
		$keyword = $this->input->post('keyword', true);
		$this->db->like('nama', $keyword, 'both');
		$this->db->or_like('hp', $keyword, 'both');
		$this->db->or_like('email', $keyword, 'both');
		return $this->db->get('register')->result_array();
    }
    
    public function hapusDataUser($id)
	{
		$this->db->where('id', $id);
		$this->db->delete('register');
	}

	public function getUserById($id)
	{
		$this->db->where('id', $id);
		return $this->db->get('register')->row_array();

	}

	public function ubahDataUser($id)
	{
		$data = [
			"nama" => $this->input->post('nama', true),
			"hp" => $this->input->post('hp', true),
			"email" => $this->input->post('email', true),
		];
		$this->db->where('id', $id);
		return $this->db->update('register', $data);
	}
}