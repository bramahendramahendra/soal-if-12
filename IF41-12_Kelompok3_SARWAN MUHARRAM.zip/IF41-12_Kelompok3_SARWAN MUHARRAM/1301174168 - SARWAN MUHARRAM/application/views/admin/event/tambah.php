<div class="container">
    <div class="titleBox flex flex-center">
        <h2 class="title text-center" id="titleFilters"><?php echo $judul ?></h2>
    </div>
    <div class="theContents Events">
        <div class="scroll">
            <div id="data" class="event-list">
                <form method="POST" action="<?php echo base_url(); ?>event/simpan" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="formGroupExampleInput">Judul</label>
                        <input type="text" class="form-control" id="formGroupExampleInput2"
                            placeholder="Apa judul event kamu?" name="judul" required>
                    </div>
                    <div clsass="form-group">
                        <label for="formGroupExampleInput">Tanggal</label>
                        <input type="date" class="form-control" id="formGroupExampleInput2"
                            placeholder="Tanggal berapa nih?" name="tanggal" required>
                    </div>
                    <div class="form-group">
                        <label for="formGroupExampleInput2">Waktu</label>
                        <input type="text" class="form-control" id="formGroupExampleInput2"
                            placeholder="Kapan waktu event kamu? Contoh : 19:00" name="waktu" required>
                    </div>
                    <div class="form-group">
                        <label for="formGroupExampleInput2">Tempat</label>
                        <input type="text" class="form-control" id="formGroupExampleInput2"
                            placeholder="Dimana lokasi event kamu?" name="tempat" required>
                    </div>
                    <div class="form-group">
                        <label for="formGroupExampleInput2">Harga</label>
                        <input type="text" class="form-control" id="formGroupExampleInput2"
                            placeholder="Satu tiket nya dihargai berapa rupiah?" name="harga" required>
                    </div>
                    <div class="form-group">
                        <label for="formGroupExampleInput2">Jumlah</label>
                        <input type="text" class="form-control" id="formGroupExampleInput2"
                            placeholder="Jumlah tiketnya ada berapa?" name="jumlah" required>
                    </div>
                    <div class="form-group">
                        <label for="formGroupExampleInput2">Tag</label>
                        <input type="text" class="form-control" id="formGroupExampleInput2"
                            placeholder="Pisahkan setiap tag dengan koma" name="tag" required>
                    </div>
                    <div class="form-group">
                        <label for="formGroupExampleInput2">Jenis Tiket</label>
                        <input type="text" class="form-control" id="formGroupExampleInput2"
                            placeholder="Apa jenis tiket acara kamu?" name="jenis_tiket" required>
                    </div>
                    <div class="form-group">
                        <label for="formGroupExampleInput2">Deskripsi</label>
                        <textarea name="deskripsi" id="" class="form-control" cols="30" rows="10" required></textarea>
                    </div>
                    <div class="form-group">
                        <label for="formGroupExampleInput2">Gambar</label>
                    </div>
                    <div class="form-group">
                        <input type="file" name="berkas" required />
                    </div>
            </div>
            <div class="modal-footer">
                <a href="<?php echo base_url() ?>event"><button type="button" class="btn btn-secondary"
                        data-dismiss="modal">Kembali</button></a>
                <input type="submit" class="btn btn-primary" id="hapus" value="Submit" placeholder="Simpan">
                </form>
            </div>

        </div>
    </div>
</div>