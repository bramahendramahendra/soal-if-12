<!DOCTYPE html>
<html lang="en" prefix="og: http://ogp.me/ns#" class="">
<head>
    <title>Register</title>
</head>
<body>
    <div class="mfp-bg my-mfp-zoom-in mfp-ready"></div>
    <div class="mfp-wrap mfp-close-btn-in mfp-auto-cursor my-mfp-zoom-in mfp-ready" tabindex="-1" style="top: 0px; position: absolute; height: 618px;">
        <div class="mfp-container mfp-inline-holder">
            <div class="mfp-content">
                <div class="popup-container" id="popup-register">
                    <div class="popup-header">
                        <h3>Daftar</h3>
                    </div>
                    <div class="popup-body">
                        <form class="login-form" role="form" method="POST" action="Reg/tambah">
                            <input type="hidden" name="_token" value="PpkrsXGcjaUmOl08aOTZwmKrTSg4Pgq421pH0vQh">
                            <div class="form-group">
                                <input id="fullname" type="text" class="form-control" name="nama" placeholder="Nama Panjang (sesuai KTP/Passport/SIM)" value="" required="" autofocus="">
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col-md-3">
                                        <div class="phoneCodeBox">
                                            <select name="hp_code" id="phone_code" class="form-control select select2-hidden-accessible" data-live-search="true" tabindex="-1" aria-hidden="true">
                                                <option value="673">+673 - Brunei Darussalam</option>
                                                <option value="62" selected="">+62 - Indonesia</option>
                                                <option value="60">+60 - Malaysia</option>
                                                <option value="95">+95 - Myanmar</option>
                                                <option value="63">+63 - Philippines</option>
                                                <option value="65">+65 - Singapore</option>
                                                <option value="66">+66 - Thailand</option>
                                                <option value="84">+84 - Vietnam</option>
                                            </select>
                                            <span class="select2 select2-container select2-container--default" dir="ltr" style="width: 100px;">
                                                <span class="selection">
                                                    <span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-phone_code-container">
                                                        <span class="select2-selection__rendered" id="select2-phone_code-container" title="+62 - Indonesia">+62 - Indonesia</span>
                                                        <span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span>
                                                    </span>
                                                </span>
                                                <span class="dropdown-wrapper" aria-hidden="true"></span>
                                            </span>
                                        </div>
                                    </div>
                                    <div class="col-md-9">
                                        <input class="form-control" placeholder="No. Handphone" name="hp" type="text">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <input class="form-control dob" placeholder="Tanggal Lahir (dd/mm/yyyy)" name="bday" type="text" maxlength="10">
                            </div>
                            <div class="form-group">
                                <select name="negara" id="country_id" class="form-control select select2-hidden-accessible" tabindex="-1" aria-hidden="true">
                                    <option value="1">Brunei Darussalam</option>
                                    <option value="2" selected="selected">Indonesia</option>
                                    <option value="3">Malaysia</option>
                                    <option value="4">Myanmar</option>
                                    <option value="5">Philippines</option>
                                    <option value="6">Singapore</option>
                                    <option value="7">Thailand</option>
                                    <option value="8">Vietnam</option>
                                </select>
                                <span class="select2 select2-container select2-container--default" dir="ltr" style="width: 100px;">
                                    <span class="selection">
                                        <span class="select2-selection select2-selection--single" role="combobox" aria-haspopup="true" aria-expanded="false" tabindex="0" aria-labelledby="select2-country_id-container">
                                            <span class="select2-selection__rendered" id="select2-country_id-container" title="Indonesia">Indonesia</span>
                                            <span class="select2-selection__arrow" role="presentation"><b role="presentation"></b></span>
                                        </span>
                                    </span>
                                    <span class="dropdown-wrapper" aria-hidden="true"></span>
                                </span>
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" name="email" placeholder="Email" value="" required="">
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" name="email_conf" placeholder="Ulangi email" value="" required="">
                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" placeholder="pass" name="pass" required="">
                            </div>
                            <div class="form-group">
                                <input id="password-confirm" type="password" class="form-control" placeholder="Ulangi Kata Sandi" name="pass_conf" required="">
                            </div>
                            <div class="form-group">
                                <input id="checkbox" type="checkbox" required="">
                                <span>Saya setuju dengan<a href="https://www.kiostix.com/page/terms-conditions">"Syarat dan Ketentuan yang berlaku."</a></span>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="button btn-primary">Daftar</button>
                            </div>
                        </form>
                    </div>
                    <button title="Close (Esc)" type="button" class="mfp-close">×</button>
                </div>
            </div>
        </div>
    </div>
</body>
</html>