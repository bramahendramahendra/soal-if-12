<!DOCTYPE html>
<html>

<head>
    <title>Kiostix - Solusi Tepat Tiket Event Anda </title>
    <link rel="icon" type="image/x-icon" href="<?php echo base_url() ?>assets/img/favicon.png">
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/css.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/css/bootstrap.css">
    <link href='https://fonts.googleapis.com/css?family=Montserrat' rel='stylesheet'>
    <link href="https://unpkg.com/ionicons@4.5.5/dist/css/ionicons.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/owlcarousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="<?php echo base_url() ?>assets/owlcarousel/assets/owl.theme.default.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
    <script src="<?php echo base_url() ?>assets/owlcarousel/owl.carousel.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mouse0270-bootstrap-notify/3.1.5/bootstrap-notify.min.js">
    </script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.2.3/animate.min.css"></script>
</head>

<body class="body_right">
    <?php
    $message = $this->session->flashdata('message');
    //   echo "$message";
    if ($message == "error") {
        ?>
    <script type="text/javascript">
    $(document).ready(function() {
        $.notify({
            title: '<strong>ERROR</strong>',
            icon: 'icon ion-md-alert',
            message: "Email or Password wrong!"
        }, {
            type: 'danger',
            animate: {
                enter: 'animated fadeInUp',
                exit: 'animated fadeOutRight'
            },
            placement: {
                from: "bottom",
                align: "right"
            },
            offset: 20,
            spacing: 10,
            z_index: 1031,
        });
    });
    </script>
    <?php
        };
        ?>
    <?php
            $message = $this->session->flashdata('message');
            if ($message == "success") {
                ?>
    <script type="text/javascript">
    $(document).ready(function() {
        $.notify({
            title: '<strong>SUCCESS</strong>',
            icon: 'icon ion-md-done',
            message: "Account has been created!"
        }, {
            type: 'success',
            animate: {
                enter: 'animated fadeInUp',
                exit: 'animated fadeOutRight'
            },
            placement: {
                from: "bottom",
                align: "right"
            },
            offset: 20,
            spacing: 10,
            z_index: 1031,
        });
    });
    </script>
    <?php
        };
        ?>
    <?php
        $message = $this->session->flashdata('message');
        //   echo "$message";
        if ($message == "error_not_match") {
            ?>
    <script type="text/javascript">
    $(document).ready(function() {
        $.notify({
            title: '<strong>ERROR</strong>',
            icon: 'icon ion-md-alert',
            message: "Confirmation Email or Password doesnt match!"
        }, {
            type: 'danger',
            animate: {
                enter: 'animated fadeInUp',
                exit: 'animated fadeOutRight'
            },
            placement: {
                from: "bottom",
                align: "right"
            },
            offset: 20,
            spacing: 10,
            z_index: 1031,
        });
    });
    </script>
    <?php
            };
            ?>
    <!-- Modal -->
    <div class="modal fade" id="myModal" role="dialog">
        <div class="modal-dialog" style="margin-top: 15%;">
            <!-- Modal content-->
            <div class="popup-container" id="popup-login">
                <div class="popup-header">
                    <h3>Login</h3>
                    <button title="Close (Esc)" type="button" class="mfp-close" data-dismiss="modal"
                        style="margin-top: 2.5%;">×</button>
                </div>
                <!-- /.popup-header -->
                <div class="popup-body">
                    <form class="login-form" role="form" method="POST" action="<?php echo base_url() ?>Log/masuk">
                        <div class="form-group">
                            <input id="email" type="email" class="form-control" placeholder="Email" name="email"
                                value="" required autofocus>
                        </div>
                        <div class="form-group">
                            <input id="password" type="password" class="form-control" placeholder="Kata Sandi"
                                name="password" autocomplete="off" required>
                        </div>
                        <div class="form-group">
                            <div class="remember-me">
                                <input type="checkbox" name="remember" class="checkbox">
                                <label>
                                    Ingatkan saya </label>
                            </div>
                        </div>
                        <div class="form-group center">
                            <div class="row">
                                <div class="col-md-6">
                                    <button type="submit" class="button setCookie">
                                        Masuk </button>
                                </div>
                                <div class="col-md-6">
                                    <a href="#popup-register" class="button showPopup" data-toggle="modal"
                                        data-dismiss="modal" data-target="#myModal2">
                                        <span>Daftar</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="form-group center">
                            <span>atau</span>
                        </div>
                        <div class="form-group center">
                            <div class="socialLogin">

                                <a href="#" class="button loginFacebook setCookie"> <i
                                        class="icon ion-logo-facebook"></i> Login</a>
                                <a href="#" class="button loginGoogle setCookie"> <i
                                        class="icon ion-logo-googleplus"></i> Login</a>
                            </div>
                        </div>
                        <div class="form-group center">
                            <a class="btn btn-link" href="reset">
                                Lupa Kata Sandi </a>
                        </div>
                    </form>
                </div>
                <!-- /.popup-body -->
            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="myModal2" role="dialog">
        <div class="modal-dialog" style="margin-top: 2%;">
            <!-- Modal content-->
            <div class="popup-container" id="popup-register">
                <div class="popup-header">
                    <h3>Daftar</h3>
                    <button title="Close (Esc)" type="button" class="mfp-close" data-dismiss="modal"
                        style="margin-top: 2.5%;">×</button>
                </div>
                <!-- /.popup-header -->
                <div class="popup-body">
                    <form class="login-form" role="form" method="POST" action="<?php echo base_url() ?>Reg/tambah">
                        <div class="form-group">
                            <input id="fullname" type="text" class="form-control" name="nama"
                                placeholder="Nama Panjang (sesuai KTP/Passport/SIM)" value="" required autofocus>
                        </div>
                        <div class="form-group">
                            <div class="row">
                                <div class="col-md-3">
                                    <div class="phoneCodeBox">
                                        <select name="hp_code" id="phone_code" class="form-control select"
                                            data-live-search="true">
                                            <option value="93">+93 - Afghanistan</option>
                                            <option value="93">+93 - asda</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-9">
                                    <input class="form-control" placeholder="No. Handphone" name="hp" type="text">
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <input class="form-control dob" placeholder="Tanggal Lahir (dd/mm/yyyy)" name="bday"
                                type="text">
                        </div>
                        <div class="form-group">
                            <select name="negara" id="country_id" class="form-control select">
                                <option value="1">Afghanistan</option>
                            </select>
                        </div>

                        <div class="form-group">

                            <input type="email" class="form-control" name="email" placeholder="Email" value="" required>

                        </div>
                        <div class="form-group">

                            <input type="email" class="form-control" name="email_conf" placeholder="Ulangi email"
                                value="" required>
                        </div>

                        <div class="form-group">

                            <input type="password" class="form-control" placeholder="Kata Sandi" name="pass" required>

                        </div>

                        <div class="form-group">
                            <input id="password-confirm" type="password" class="form-control"
                                placeholder="Ulangi Kata Sandi" name="pass_conf" required>
                        </div>

                        <div class="form-group">
                            <input id="checkbox" type="checkbox" required>
                            <span>Saya setuju dengan<a href="#">"Syarat dan Ketentuan yang berlaku."</a></span>
                        </div>

                        <div class="form-group">
                            <button type="submit" class="button btn-primary">
                                Daftar </button>
                        </div>
                    </form>
                </div>
                <!-- /.popup-body -->
            </div>
        </div>
    </div>

    <div class="flex-container">
        <header>
            <div id="top">
                <div id="sticky" class="header-box sticky">
                    <div class="container">
                        <div class="flex-center">
                            <a href="<?php echo base_url() ?>" class="logo">
                                <img src="<?php echo base_url() ?>assets/img/logo.png" alt="kiosTix">
                            </a>
                            <div id="navigation">
                                <div class="navigation">
                                    <nav>
                                        <ul id="menu">
                                            <li>
                                                <a href="<?php echo base_url() ?>eve/eventt" class=" ">Events</a>
                                            </li>
                                            <li>
                                                <a href="#" class=" ">Aktivitas dan Hiburan</a>
                                            </li>
                                        </ul>
                                    </nav>
                                </div>
                            </div>
                            <div class="socmed">
                                <div class="ag-lang">
                                    <a class=" active " href="">ID</a>
                                    <span>|</span>
                                    <a class="" href="">EN</a>
                                </div>
                                <a href="#" target="_blank"><i class="icon ion-logo-instagram"></i></a>
                                <a href="#" target="_blank"><i class="icon ion-logo-facebook"></i></a>
                                <a href="#" target="_blank"><i class="icon ion-logo-twitter"></i></a>
                                <a href="#" target="_blank"><i class="icon ion-logo-youtube"></i></a>
                            </div>
                            <?php
                            if ($this->session->userdata('status') != "login") {
                                ?>
                            <div class="box-nav">
                                <ul id="topnav">
                                    <li>
                                        <a href="#popup-login" class="showPopup button btn-outline btn-s login"
                                            data-toggle="modal" data-target="#myModal">
                                            <span>Masuk</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <?php
                        } else {
                            ?>
                            <div class="box-nav">
                                <ul id="topnav">
                                    <li>
                                        <a href="my-account" class="">
                                            <i class="icon ion-md-person"></i> <span>Hi,
                                                <?php
                                                                                                echo strtok($this->session->userdata('nama'), ' '); ?>...</span>
                                        </a>
                                    </li>
                                    <li class="logout-btns">
                                        <a href="<?php echo base_url() ?>Log/logout">
                                            <i class="icon ion-md-lock"></i> <span>Keluar</span>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                            <?php
                        }
                        ?>
                        </div>
                    </div>
                </div>
            </div>

        </header>
