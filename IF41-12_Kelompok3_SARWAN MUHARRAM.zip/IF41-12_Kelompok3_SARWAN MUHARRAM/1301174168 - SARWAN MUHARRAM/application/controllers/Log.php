<?php
 // Sarwan Muharram 1301174168
class Log extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Mlog');
	}

	public function index()
	{
		redirect('home');
	}

	public function masuk()
	{
        $email = $this->input->post('email');
		//perbaiki baris ini
		//perbaiki baris ini
        // var_dump($pass);
        if ($data != NULL){
		$data_session = array(
			'id' => $data["id"],
			'nama' => $data["nama"],
			'status' => "login"
			);
		$this->session->set_userdata($data_session);
		redirect('home');
        }else{
		$this->session->set_flashdata('message', 'error');
            	redirect('home');
        }
	}

	function logout(){
		$this->session->sess_destroy();
		redirect(base_url('home'));
	}
}