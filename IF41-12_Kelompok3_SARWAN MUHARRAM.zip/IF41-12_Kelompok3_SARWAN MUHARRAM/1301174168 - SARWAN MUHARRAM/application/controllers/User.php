<?php
class User extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
				$this->load->model('Muser');
        $this->load->model('Mreg');
				$this->load->library("form_validation");
				if ($this->session->userdata('status') != "admin") {
					redirect('admin/login');
				}
	}

	public function index()
	{
		$data['judul'] = 'Daftar User';
		$data['user'] = $this->Muser->getAllUser();
		if ($this->input->post('keyword')) {
			$data['user'] = $this->Muser->cariDataUser();
		}
		$this->load->view('layouts/header-admin', $data);
		$this->load->view('admin/user/user', $data);
		$this->load->view('layouts/footer-admin');
	}

	public function tambah()
	{
		$data['judul'] = 'Tambah User';
		$this->load->view('layouts/header-admin', $data);
		$this->load->view('admin/user/tambah', $data);
		$this->load->view('layouts/footer-admin');
	}

	public function simpan()
	{
		if ($this->input->post('email')!=$this->input->post('email_conf')){
			$this->session->set_flashdata('message', 'error_not_match');
							redirect('user/tambah');
		}
		if ($this->input->post('pass')!=$this->input->post('pass_conf')){
			$this->session->set_flashdata('message', 'error_not_match');
							redirect('user/tambah');
		}
		$this->Mreg->tambahDataUser();
		$this->session->set_flashdata('message', 'success');
		redirect('user');
	}
	
	public function ubah($id)
	{
		$data['judul'] = 'Form Ubah Data User';

		$data['user'] = $this->Muser->getUserById($id);

		$this->form_validation->set_rules('nama', 'Nama','required');
		$this->form_validation->set_rules('hp', 'HP','required');
		$this->form_validation->set_rules('email', 'Email','required|valid_email');

		if ($this->form_validation->run() == false) {
			$this->load->view('layouts/header-admin', $data);
			$this->load->view("admin/user/ubah", $data);
			$this->load->view('layouts/footer-admin');
		}else{
			$this->Muser->ubahDataUser($id);
			$this->session->set_flashdata('flash','changed success');
			redirect('user');
		}
		}
		
		public function lihat($id)
	{
		$data['judul'] = 'Form Ubah Data User';
		$data['user'] = $this->Muser->getUserById($id);
		$this->load->view('layouts/header-admin', $data);
		$this->load->view('admin/user/lihat', $data);
		$this->load->view('layouts/footer-admin');
	}
    
    public function hapus($id)
	{
		$this->Muser->hapusDataUser($id);
		$this->session->set_flashdata('flash', 'dihapus');
		redirect('user');

	}
}