<?php

class Madmin extends CI_model
{
	public function getAllUser()
	{
		$this->db->select('*');
		$this->db->from('admin');
		$getm = $this->db->get();
		return $getm->result_array();
	}

	public function cekDataUser($email,$pass)
	{
        $this->db->where('email',$email);
        $this->db->where('password',$pass);
				return $this->db->get('admin')->row_array();
	}
}
