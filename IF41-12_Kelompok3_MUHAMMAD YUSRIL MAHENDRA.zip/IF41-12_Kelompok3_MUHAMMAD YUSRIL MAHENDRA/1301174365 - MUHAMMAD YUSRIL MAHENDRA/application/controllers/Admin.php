<?php

class Admin extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Muser');
        $this->load->model('Madmin');
        $this->load->library("form_validation");
	}

	public function index()
	{
		if ($this->session->userdata('status') == "admin") {
			redirect('user/index');
		}else{
			redirect('admin/login');
		}
    }
    
    public function login()
    {
	    $this->load->view('admin/login');
	}

	public function masuk()
	{
        $email = $this->input->post('email');
        $pass = $this->input->post('password');
        $data = $this->Madmin->cekDataUser($email,$pass);
        // var_dump($data);
        if ($data != NULL){
		$data_session = array(
			'nama' => $data["username"],
			'status' => "admin"
			);
		// perbaiki baris ini
		// perbaiki baris ini
        }else{
		$this->session->set_flashdata('message', 'error');
            	redirect('admin/login');
        }
	}

	function logout(){
		$this->session->sess_destroy();
		redirect(base_url('home'));
	}
}