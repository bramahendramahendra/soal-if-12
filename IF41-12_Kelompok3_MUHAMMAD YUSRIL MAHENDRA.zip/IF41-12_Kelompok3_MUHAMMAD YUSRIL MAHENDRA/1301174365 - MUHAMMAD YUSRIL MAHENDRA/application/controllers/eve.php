
<?php

class eve extends CI_Controller
{
  public function __construct()
	{
		parent::__construct();
		$this->load->model('Mevent');

	}

  public function eventt()
  {
    $data_event = $this->Mevent->Getevent();
		$this->load->view('layouts/header');
    $this->load->view('event',['data'=>$data_event]);
    $this->load->view('layouts/footer');
  }

  public function eventtambah()
  {
    $data_event = $this->Mevent->Getevent();
    $this->load->view('tambaheventview',['data'=>$data_event]);
  }

  public function infoeventt()
  {
    $data_event = $this->Mevent->Getevent();
    $this->load->view('infoevent',['d'=>$data_event]);
    $this->Mevent->Getevent($id);
  }

  public function eventhapus()
  {
    $data_event = $this->Mevent->Getevent();
    $this->load->view('hapuseventview',['data'=>$data_event]);
  }

  public function hapusevent($id) {
    $where = array('id' => $id);
		$this->mevent->hapus_event($where,'event');
		redirect('index.php/eve/eventtambah');
  }

  public function tambahevent()
  {
    $judul = $this->input->post('judul');
    $tanggal = $this->input->post('tanggal');
    $tempat = $this->input->post('tempat');
    $deskripsi = $this->input->post('deskripsi');
    $harga = $this->input->post('harga');
    $data = array(
      'judul' => $judul,
      'tanggal' => $tanggal,
      'tempat' => $tempat,
      'deskripsi' => $deskripsi,
      'harga' => $harga,
    );
    $this->Mevent->tambah_event($data);

    redirect('index.php/eve/eventtambah');

  }

  public function eventedit()
  {
    $data_event = $this->Mevent->Getevent();
    $this->load->view('editeventview',['data'=>$data_event]);
  }

  public function editevent()
	{
		$judul = $this->input->post('judul');
		$tanggal = $this->input->post('tanggal');
		$tempat = $this->input->post('tempat');
		$deskripsi = $this->input->post('deskripsi');
    $harga = $this->input->post('harga');

		$data = array(
			'judul' => $judul,
			'tanggal' => $tanggal,
			'tempat' => $tempat,
      'deskripsi' => $deskripsi,
      'harga' => $harga,
		);
		$this->Mevent->edit_event($id,$data);

		redirect('index.php/eve/eventedit');
	}

  public function detailevent($id)
  {
    $data['event'] = $this->Mevent->getEventById($id);
		$this->load->view('layouts/header', $data);
		$this->load->view('detailevent', $data);
    $this->load->view('layouts/footer');
    $this->session->set_userdata('referred_from', current_url());
  }
}
