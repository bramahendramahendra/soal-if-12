<?php
class Checkout extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
        $this->load->model('Muser');
		$this->load->model('Mevent');
		$this->load->model('Mreg');
		$this->load->model('Mbayar');
        $this->load->model('Mtiket');
        $this->load->library("form_validation");
        if ($this->session->userdata('status') != "login") {
            redirect('home');
        }
	}

	public function index()
	{
		$this->session->keep_flashdata('key');
		$data = $this->session->flashdata('key');
		$this->load->view('layouts/header', $data);
		$this->load->view('checkout', $data);
		$this->load->view('layouts/footer');
    }

	public function pesan()
	{
		// echo "yeye";
		// echo $this->input->post('quantity');
		$referred_from = $this->session->userdata('referred_from');
		if($this->input->post('quantity') <= 0){
			$this->session->set_flashdata('message', 'quantity_zero');
			redirect($referred_from);
		}else{
			$id_bayar = $this->Mbayar->tambahDataBayar();
			$id_user = $this->session->userdata('id');
			$id_event = $this->input->post('id');
			for($i=1; $i<= $this->input->post('quantity'); $i++){
				$this->Mtiket->tambahDataTiket($id_event, $id_user, $id_bayar);
			}
			$data['judul'] = 'Checkout';
			$data['event'] = $this->Mevent->getEventById($id_event);
			$data['user'] = $this->Muser->getUserById($id_user);
			$data['bayar'] = $this->Mbayar->getBayarById($id_bayar);
			$data['quantity'] = $this->input->post('quantity');
			$this->session->set_flashdata('key',$data);
			$this->session->keep_flashdata('key');
			redirect('checkout/index');
		}	
		// $data['judul'] = 'Tambah Event';
		// $this->load->view('layouts/header-admin', $data);
		// $this->load->view('admin/event/tambah', $data);
		// $this->load->view('layouts/footer-admin');
	}
	public function simpan()
	{
		// echo $this->input->post('metode_pembayaran');
		$id_event =  $this->input->post('id_event');
		$id_user =  $this->input->post('id_user');
		$id_bayar =  $this->input->post('id_pembayaran');
		$this->Mbayar->ubahDataBayar($id_bayar);
		$data['judul'] = 'Bayar';
		$data['event'] = $this->Mevent->getEventById($id_event);
		$data['user'] = $this->Muser->getUserById($id_user);
		$data['bayar'] = $this->Mbayar->getBayarById($id_bayar);
		// echo $data['event']['judul'];
		$this->session->set_flashdata('key2',$data);
		$this->session->keep_flashdata('key2');
		redirect('checkout/bayar');
	}
	
	public function ubah($id)
	{
		$data['event'] = $this->Mevent->getEventById($id);
		$this->Mbayar->ubahDataBayar($id);
		redirect('checkout/bayar');
	}
		
	public function bayar()
	{
		$this->session->keep_flashdata('key2');
		$data = $this->session->flashdata('key2');
		// echo $data['event']['judul'];
		$this->load->view('layouts/header', $data);
		$this->load->view('bayar', $data);
		$this->load->view('layouts/footer');
	}
    
    public function hapus($id)
	{
		$this->Mevent->hapusDataEvent($id);
		$this->session->set_flashdata('message', 'dihapus');
		redirect('event');

	}
}