<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Mbayar extends CI_Model {

	// public function getAllEvent()
	// {
		
	// 	return $this->db->get("event")->result_array();

    // }
    
    // public function cariDataEvent()
	// {
	// 	$keyword = $this->input->post('keyword', true);
	// 	$this->db->like('judul', $keyword, 'both');
	// 	$this->db->or_like('tempat', $keyword, 'both');
	// 	$this->db->or_like('harga', $keyword, 'both');
	// 	return $this->db->get('event')->result_array();
    // }
	
	public function tambahDataBayar()
	{
        date_default_timezone_set('Asia/Jakarta'); # add your city to set local time zone
        $now = date('Y-m-d H:i:s');
		$data = [
			"total" => $this->input->post('quantity', true)*$this->input->post('harga', true),
            "status" => "create",
			"timestamp" => $now,
		];
        $this->db->insert('pembayaran', $data);
        $cid = $this->db->insert_id();
        return $cid;
	}
	
    // public function hapusDataEvent($id)
	// {
	// 	$this->db->where('id', $id);
	// 	$this->db->delete('event');
	// }

	public function getBayarById($id)
	{
		$this->db->where('id', $id);
		return $this->db->get('pembayaran')->row_array();

	}

	public function ubahDataBayar($id)
	{
        date_default_timezone_set('Asia/Jakarta'); # add your city to set local time zone
        $now = date('Y-m-d H:i:s');
		$data = [
			"metode_bayar" => $this->input->post('metode_pembayaran', true),
            "barcode" => "https://api.veritrans.co.id/v2/gopay/2f342175-6d2a-4907-8f7e-f0e1bb52337d/qr-code",
            "status" => "checkout",
			"timestamp" => $now,
		];
		$this->db->where('id', $id);
		return $this->db->update('pembayaran', $data);
	}

}
