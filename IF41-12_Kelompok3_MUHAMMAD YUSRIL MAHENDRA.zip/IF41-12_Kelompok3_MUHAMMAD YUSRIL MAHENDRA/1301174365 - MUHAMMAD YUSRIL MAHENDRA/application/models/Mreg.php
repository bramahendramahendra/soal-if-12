<?php
 // Sarwan Muharram 1301174168
class Mreg extends CI_model
{
	public function getAllUser()
	{
		$this->db->select('*');
		$this->db->from('register');
		$getm = $this->db->get();
		return $getm->result_array();
	}

	public function tambahDataUser()
	{
		$data = [
			"nama" => $this->input->post('nama', true),
            "hp" => $this->input->post('hp', true),
            "bday" => $this->input->post('bday', true),
            "negara" => $this->input->post('negara', true),
			"email" => $this->input->post('email', true),
			"pass" => md5($this->input->post('pass', true)),
		];
		$this->db->insert('register', $data);
    }
}
