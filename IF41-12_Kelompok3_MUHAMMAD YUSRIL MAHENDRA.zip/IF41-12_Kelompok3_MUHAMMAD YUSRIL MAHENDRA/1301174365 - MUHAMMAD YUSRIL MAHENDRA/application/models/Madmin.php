<?php

class Madmin extends CI_model
{
	public function getAllUser()
	{
		$this->db->select('*');
		$this->db->from('admin');
		$getm = $this->db->get();
		return $getm->result_array();
	}

	public function cekDataUser($email,$pass)
	{
		//perbaiki baris ini
		//perbaiki baris ini
		//perbaiki baris ini
	}
}
